import os


def get_files_modify_time(local_model_path):
    """
    Record local model files.
    :param local_model_path: directory path
    :return a dictionary describing every file and directory modification time
    """
    file_map = dict()
    files = os.listdir(local_model_path)
    for single_file in files:
        single_file_path = os.path.join(local_model_path, single_file)
        file_map[single_file_path] = str(os.path.getmtime(single_file_path))
    return file_map
