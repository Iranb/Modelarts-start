import configparser
import os


class _Config(object):

    def __init__(self, conf_file):
        self._CONFIG = configparser.ConfigParser()
        config_file = conf_file
        self._CONFIG.read(config_file)

    def getenv(self, key, default=None):
        try:
            if os.getenv(key) is not None:
                return os.getenv(key)
            else:
                sections = key.split('_', 1)
                value = self._CONFIG[sections[0]][sections[1]]
                return value
        except Exception:
            return default

    def get(self, key, default=None):
        try:
            if os.getenv(key) is not None:
                return os.getenv(key)
            else:
                sections = key.split('_', 1)
                value = self._CONFIG[sections[0]][sections[1]]
                return value
        except Exception:
            return default

    def getconfig(self):
        return self._CONFIG


default_config_file = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")) + '/config/config.ini'
Config = _Config(default_config_file)
