"""
Description: Start a process and execute a command
Author: ModelArts SDK Team
Date: 2020/10/01 - 2020/10/30
"""
import subprocess
import sys
import time
import re

from threading import Thread


def _log_handler(file):
    for line in iter(file.readline, ""):
        if isinstance(line, bytes):
            try:
                stripped = line.decode().rstrip("\r\n")
                last = stripped.split("\r")[-1]
                sys.stdout.write(last + "\n")
                sys.stdout.flush()
            except Exception:
                continue

        if not line:
            break


def execute_command(*popenargs, **kwargs):
    """
    execute a command
    :param popenargs: parameters of Popen command
    """
    kwargs["stdout"] = kwargs.get("stdout") or subprocess.PIPE
    kwargs["stderr"] = kwargs.get("stderr") or subprocess.PIPE

    try:
        line_buffer = ["stdbuf", "-oL", "-eL"]
        line_buffer.extend(*popenargs)
        process = subprocess.Popen(line_buffer, **kwargs)
        stdout_thread = Thread(target=_log_handler, args=[process.stdout])
        stderr_thread = Thread(target=_log_handler, args=[process.stderr])
        stdout_thread.daemon = stderr_thread.daemon = True
        stdout_thread.start()
        stderr_thread.start()

        while process.returncode is None:
            time.sleep(0.1)
            process.poll()

        stdout_thread.join()
        stderr_thread.join()
    except Exception as e:
        exception_handler = kwargs.get("exception_handler")
        if exception_handler:
            exception_handler(e)
        else:
            raise

    if process.returncode:
        raise subprocess.CalledProcessError(process.returncode, popenargs[0])
    return 0
