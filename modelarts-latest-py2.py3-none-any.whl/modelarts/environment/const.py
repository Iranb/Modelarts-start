"""Constants for conda and docker environments."""
ENV_NAME = "name"
ENV_VERSION = "version"
ENV_AUTHOR = "author"

ENV_VARS = "environment-variables"

CONDA_ENV = "conda"
CHANNELS = "channels"
CONDA_PACKAGES = "conda-packages"
PIP_PACKAGES = "pip-packages"

DOCKER_ENV = "docker"
DOCKER_IMAGE = "image"
DOCKERFILE = "Dockerfile"

TASK_STATES = [
    'UNKNOWN',
    'RUNNING',
    'FAILED',
    'COMPLETED'
]

TASK_UNKNOWN_INDEX = 0
TASK_TASK_RUNNING_INDEX = 1
TASK_TASK_FAILED_INDEX = 2
TASK_TASK_COMPLETED_INDEX = 3


LOCAL_ENV_STORAGE_DIRECTORY_ENV_NAME = "LOCAL_ENV_STORAGE_DIRECTORY"
DEFAULT_LOCAL_ENV_STORAGE_DIRECTORY = "/home/ma-user/work/.environments"
LOCAL_MA_ENV_STORAGE_DIRECTORY_ENV_NAME = "LOCAL_MA_ENV_STORAGE_DIRECTORY"
DEFAULT_LOCAL_MA_ENV_STORAGE_DIRECTORY = "/home/ma-user/modelarts-sdk/modelarts/.environments"
DEFAULT_CONDA_BIN_PATH = "conda"
