"""
Release the operator to the modelarts market.
"""
from .config.auth import auth_by_apig
from json import JSONEncoder
from . import constant


class Market(object):

    def __init__(self, session, framework, file_url, title_flag=None,
                 python_api=None, cpp_api=None, custom_type=None,
                 quantization=False, provider=None):

        """
        Initialize a market, determine the attributes of the operator.
        :param session: Building interactions with HUAWEI Cloud service.
        :param framework: tensorflow or caffe
        :param file_url: obs address of the operator
        :param title_flag: operator name tag
        :param python_api: operator name,python_api
        :param cpp_api: operator name,cpp_api
        :param custom_type: whether it is a custom operator
        :param quantization: quantization tool support
        :param provider: obs or ma
        """

        self.session = session
        self.framework = framework
        self.file_url = file_url
        self.title_flag = title_flag
        self.python_api = python_api
        self.cpp_api = cpp_api
        self.custom_type = custom_type
        self.quantization = quantization
        self.provider = provider

    def generate_body(self):

        """ get request body
        :return: json: request body of the operator
        """
        body = {
            "title_flag": self.title_flag,
            "framework": self.framework,
            "chipset": [
                "ascend.910"
            ],
            "custom_type": self.custom_type,
            "quantization": self.quantization,
            "config": {
                "provider": self.provider,
                "region": self.session.region_name,
                "file_url": self.file_url
            }
        }
        if self.title_flag is None:
            body["title_flag"] = 1
        if body["title_flag"] == 1:
            body["python_api"] = \
                "tf.unkwnow" if self.python_api is None else self.python_api
        else:
            body["cpp_api"] = \
                "Type:unkwnow" if self.cpp_api is None else self.cpp_api

        if self.custom_type is None:
            body["custom_type"] = 1
        if self.quantization is None:
            body["quantization"] = False
        if self.provider is None:
            body["config"]["provider"] = 1

        return JSONEncoder().encode(body)

    def release_operator(self):
        """ Release the operator to teh market
        :return: return operator information.
        """
        request_url = '/v1/aihub/ascend-operators'
        body = self.generate_body()
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url, '', body)
