"""Constants of modelarts sdk."""
import os
import sys

AKSK_AUTH = 'aksk'
ROMA_AUTH = 'roma'
ACCOUNT_AUTH = 'account'
HTTPS_GET = 'GET'
HTTPS_POST = 'POST'
HTTPS_DELETE = 'DELETE'
HTTPS_PUT = 'PUT'
ISO_TIME_FORMAT = '%m%d-%H%M%S'
JSON_TYPE = 'json'

ROMA_HOST = 'http://roma.huawei.com/csb/rest/modelarts'
ROMA_OBS_HOST = "http://roma.huawei.com/csb/api/"
ROMA_PROJECT_ID = 'roma_project_id'
ROMA_CONTENT_TYPE = 'application/json;charset=utf8'

MODELARTS_CONFIG_PATH = '~/.modelarts/config.json'

SUPPORTED_REGION = ['cn-north-1', 'cn-north-2', 'cn-north-4', 'cn-north-5',
                    'cn-north-7', 'cn-northeast-1',
                    'cn-east-2', 'cn-south-1', 'ap-southeast-1', 'cn-east-3',
                    'ap-southeast-3', 'cn-hangzhou-1', 'eu-west-0']

JOB_STATE = ['JOBSTAT_UNKNOWN', 'JOBSTAT_INIT', 'JOBSTAT_IMAGE_CREATING',
             'JOBSTAT_IMAGE_FAILED',
             'JOBSTAT_SUBMIT_TRYING',
             'JOBSTAT_SUBMIT_FAILED', 'JOBSTAT_DELETE_FAILED',
             'JOBSTAT_DEPLOYING', 'JOBSTAT_RUNNING',
             'JOBSTAT_KILLING',
             'JOBSTAT_COMPLETED', 'JOBSTAT_FAILED', 'JOBSTAT_KILLED',
             'JOBSTAT_CANCELED', 'JOBSTAT_LOST',
             'JOBSTAT_SCALING', 'JOBSTAT_CHECK_INIT', 'JOBSTAT_CHECK_RUNNING',
             'JOBSTAT_CHECK_FAILED']

ROMA_JOB_WAITING_STATUS_CODE = 1000

ROMA_JOB_WAITING_STATUS = 'JOB_WAITING'

CHECK_ROMA_WAITING_JOB_STATUS_INTERVAL = 5

ROMA_TRAIN_JOB_DEFAULT_PRIORITY = 1

LOCAL_TRAIN_TYPE = 'local'

LOCAL_TRAIN_DIR = "~/modelarts-python-sdk/local_train"

MODEL_CREATE_PARAMS = {'model_name', 'model_version', 'source_location',
                       'source_job_id', 'source_job_version',
                       'source_type', 'model_type', 'model_algorithm',
                       'description', 'execution_code', 'input_params',
                       'output_params', 'dependencies', 'model_metrics',
                       'apis', 'runtime', 'install_type', 'model_docs'}

MODEL_INDEX_PARAMS = {'model_name', 'model_version', 'model_status',
                      'description', 'offset', 'limit', 'sort_by',
                      'order'}

SERVICE_DEPLOY_PARAMS = {'service_name', 'description', 'infer_type', 'vpc_id',
                         'subnet_network_id',
                         'security_group_id', 'configs', 'cluster_id',
                         'schedule'}

SERVICE_INDEX_PARAMS = {'service_id', 'service_name', 'infer_type', 'offset',
                        'limit', 'sort_by', 'order', 'model_id',
                        'service_status'}

LOCAL_INFER_LOG = "~/log/local_infer_log/"

OBS_HEAD_FORMAT = 'obs://'

OBS_DIR_FORMAT = "obs://bucket_name/dir1/dir2/"

OBS_FILE_FORMAT = "obs://bucket_name/dir1/dir2/file.txt"

DEFAULT_THREADS = 16

ANACONDA_DIR = "ANACONDA_DIR"

DEFAULT_ANACONDA_DIR = "/home/ma-user/anaconda" + \
    sys.version.split()[0].split(".")[0]
    
DEFAULT_ENVIRONMENT_PATH = os.path.join(os.environ.get(
    ANACONDA_DIR, DEFAULT_ANACONDA_DIR), "envs/")

ENVIRONMENT_PATH_ENV_NAME = "ENVIRONMENT-PREFIX-PATH"

LOCK_DIR = "locks"

ENVIRONMENT_INSTALL_LOCK = "install_modelarts_conda"

DOCKER_IMAGE_BUILD_DIR = "/home/ma-user/work/"

DEFAULT_PIP_CONFIG_PATH = "/home/ma-user/.pip/pip.conf"

USER_PIP_CONFIG_PATH = "USER_PIP_CONFIG_PATH"

DOCKER_IMAGE_BUILD_SUCC = "success"

DOCKER_IMAGE_BUILD_MAX_TIME = 300

IMPORT_DATASET_TEMP_DIRECTORY_PREFIX = "import_temp_"

IMPORT_DATASET_WAIT_INTERVAL_TIME = 1

LOCAL_TEMP_PATH = "/local_temp_"

DATASET_VERSION_FORMAT_CARBON = "CarbonData"

DATASET_VERSION_FORMAT_CSV = "CSV"

DATASET_VERSION_FORMAT_DEFAULT = "Default"

DATASET_TYPE_TABULAR = 400

DATASET_COLUMN_TYPE_DICT = {"boolean": bool, "Boolean": bool,
                            "float": float, "Float": float, "double": float, "Double": float,
                            "int": int, "Integer": int,
                            "String": str, "string": str}

INFER_PIP_INSTALLER = "pip"

INFER_PACKAGE_RESTRAINT_DICT = {'EXACT': '==', 'ATLEAST': '>=', 'ATMOST': '<='}

INFER_INSTALL_TYPE = ["real-time", "edge", "batch"]
# For these AI frameworks and their versions of infer,
# check https://support.huaweicloud.com/engineers-modelarts/modelarts_23_0207.html
INFER_SUPPORT_RUNTIME_DICT = {
    'TensorFlow': {
        'python2.7': {'1.8': 'python2.7', '1.13': 'tf1.13-python2.7-cpu', '1.13-gpu': 'tf1.13-python2.7-gpu'},
        'python3.6': {'1.8': 'python3.6', '1.13': 'tf1.13-python3.6-cpu', '1.13-gpu': 'tf1.13-python3.6-gpu'},
        'python3.7': {'2.1': 'tf2.1-python3.7', '1.13': 'tf1.13-python3.7-cpu', '1.13-gpu': 'tf1.13-python3.7-gpu'}
    },
    'MXNet': {
        'python2.7': {'1.2': 'python2.7'},
        'python3.6': {'1.2': 'python3.6'},
        'python3.7': {'1.2': 'python3.7'}
    },
    'Caffe': {
        'python2.7': {'1.0': 'python2.7', '1.0-cpu': 'python2.7-cpu', '1.0-gpu': 'python2.7-gpu'},
        'python3.6': {'1.0': 'python3.6', '1.0-cpu': 'python3.6-cpu', '1.0-gpu': 'python3.6-gpu'},
        'python3.7': {'1.0': 'python3.7', '1.0-cpu': 'python3.7-cpu', '1.0-gpu': 'python3.7-gpu'}
    },
    'Spark_MLlib': {
        'python2.7': {'2.3': 'python2.7'},
        'python3.6': {'2.3': 'python3.6'}
    },
    'Scikit_Learn': {
        'python2.7': {'0.20': 'python2.7'},
        'python3.6': {'0.20': 'python3.6'}
    },
    'XGBoost': {
        'python2.7': {'0.80': 'python2.7'},
        'python3.6': {'0.80': 'python3.6'}
    },
    'PyTorch': {
        'python2.7': {'1.0': 'python2.7'},
        'python3.6': {'1.0': 'python3.6'},
        'python3.7': {'1.0': 'python3.7', '1.4': 'pytorch1.4-python3.7'}
    }
}
INFER_RUNTIME_TO_ENVIRONMENT = {
    'TensorFlow': {
        'python2.7': {'pip_packages': ['tensorflow==1.8.0', 'tensorflow-serving-api==1.13.0'],
                      'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['tensorflow==1.8.0', 'tensorflow-serving-api==1.13.0'],
                      'conda_packages': ['python=3.6.2']},
        'tf1.13-python2.7-gpu': {'pip_packages': ['tensorflow-gpu==1.13.2'], 'conda_packages': ['python=2.7']},
        'tf1.13-python2.7-cpu': {'pip_packages': ['tensorflow==1.13.2'], 'conda_packages': ['python=2.7']},
        'tf1.13-python3.6-gpu': {'pip_packages': ['tensorflow-gpu==1.13.2'], 'conda_packages': ['python=3.6.2']},
        'tf1.13-python3.6-cpu': {'pip_packages': ['tensorflow==1.13.2'], 'conda_packages': ['python=3.6.2']},
        'tf1.13-python3.7-gpu': {'pip_packages': ['tensorflow-gpu==1.13.2'], 'conda_packages': ['python=3.7']},
        'tf1.13-python3.7-cpu': {'pip_packages': ['tensorflow==1.13.2'], 'conda_packages': ['python=3.7']},
        'tf2.1-python3.7': {'pip_packages': ['tensorflow==2.1'], 'conda_packages': ['python=3.7']}
    },
    'MXNet': {
        'python2.7': {'pip_packages': ['mxnet==1.2.1', 'mxnet-model-server==0.3'],
                      'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['mxnet==1.2.1', 'mxnet-model-server==0.3'],
                      'conda_packages': ['python=3.6.2']},
        'python3.7': {'pip_packages': ['mxnet==1.2.1', 'mxnet-model-server==0.3'],
                      'conda_packages': ['python=3.7']}
    },
    'Caffe': {  # caffe does not support local infer, we only record runtimes
        'python2.7': {}, 'python3.6': {}, 'python3.7': {},
        'python2.7-gpu': {}, 'python3.6-gpu': {}, 'python3.7-gpu': {},
        'python2.7-cpu': {}, 'python3.6-cpu': {}, 'python3.7-cpu': {}
    },
    'Spark_MLlib': {
        'python2.7': {'pip_packages': ['pyspark==2.3.2'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['pyspark==2.3.2'], 'conda_packages': ['python=3.6.2']}
    },
    'Scikit_Learn': {
        'python2.7': {'pip_packages': ['scikit-learn==0.20.0'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['scikit-learn==0.20.0'], 'conda_packages': ['python=3.6.2']}
    },
    'XGBoost': {
        'python2.7': {'pip_packages': ['xgboost==0.80'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['xgboost==0.80'], 'conda_packages': ['python=3.6.2']}
    },
    'PyTorch': {
        'python2.7': {'pip_packages': ['torch==1.0.0', 'torchvision==0.2.1'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['torch==1.0.0', 'torchvision==0.2.1'], 'conda_packages': ['python=3.6.2']},
        'python3.7': {'pip_packages': ['torch==1.0.0', 'torchvision==0.2.1'], 'conda_packages': ['python=3.7']},
        'pytorch1.4-python3.7': {'pip_packages': ['torch==1.4.0', 'torchvision==0.5.0'],
                                 'conda_packages': ['python=3.7']}
    }
}

INFER_FRAMEWORK_ALIAS = {
    "tensorflow": ["tensorflow", "tensorflow-gpu"],
    "spark_mllib": ["pyspark"],
    "pytorch": ["torch"],
    "scikit_learn": ["scikit-learn"],
    "mxnet": ["mxnet-cu90", "mxnet"]
}

MODEL_LOCAL_LOCATION = "LOCAL_SOURCE"

MODEL_OBS_LOCATION = "OBS_SOURCE"

MODEL_SOURCE_LOCATIONS_TYPE = {MODEL_LOCAL_LOCATION, MODEL_OBS_LOCATION}

MODEL_SOURCE_LOCATION = "source_location"

MODEL_ALGORITHM_PATTERN = u"^[a-z|A-Z][^&!'\\\"<>=\u4e00-\u9fa5]{0,35}$"

PACKAGE_PATTERN = u"^[^(|);&$?\"<>`!'=\u4e00-\u9fa5\\s]{1,256}$"

MODEL_NAME_PATTERN = u"^[a-zA-Z0-9\u4e00-\u9fa5-_]{1,64}$"

MODEL_VERSION_PATTERN = "^(\\d\\.|[1-9]\\d\\.){2}(\\d|([1-9]\\d))$"

MODEL_DESCRIPTION_PATTERN = "^[^&!'\\\"<>=]{1,100}$"

DOC_NAME_PATTERN = "^[^&!'\\\"<>=]{1,48}$"

DOC_URL_PATTERN = "http[s]?://[^/]+.+"

SOURCE_LOCATION_PATTERN = "http[s]?://[^/]+/.+"

ERR_MAX_LINE_NUM = 100

DOMAIN_PATTERN = u"(?=^.{3,255}$)^[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+.?$"

HTTP_STATUS_CODE_200 = 200

HTTP_STATUS_CODE_299 = 299

LOCAL_INFER_LOG_FILE_NAME = "log.txt"
