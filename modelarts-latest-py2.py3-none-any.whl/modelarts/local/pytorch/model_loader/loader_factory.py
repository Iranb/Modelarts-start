import log
from .pytorch_model_loader import PyTorchModelLoader

logger = log.getLogger(__name__)


def scan_all_loader():
    return {
        "pytorch": PyTorchModelLoader()
    }


class ModelLoaderFactory(object):
    ModelLoaderClassDefList = scan_all_loader()

    @classmethod
    def get_instance(cls, model_type):
        if model_type.lower() not in cls.ModelLoaderClassDefList.keys():
            raise Exception("not supported model type" + str(model_type))

        return cls.ModelLoaderClassDefList[model_type.lower()]
