import os

from .model_loader import ModelLoader, load_service_class
from model_service.pytorch_model_service import PTServingBaseService


class PyTorchModelLoader(ModelLoader):

    def load(self, model):
        service_class = load_service_class(model, PTServingBaseService)
        return service_class(model.name, get_model_path(model.path))

    def unload(self, model):
        pass


def get_model_path(path):
    for item in os.listdir(path):
        if os.path.isfile(os.path.join(path, item)):
            if item.endswith('.pt') or item.endswith('.pth'):
                return os.path.join(path, item)
    raise Exception("can not find pt/pth file in {}".format(path))
