from abc import abstractmethod, ABCMeta
import os
import sys
import log

logger = log.getLogger(__name__)


def get_service_file_path(path):
    default_service_filename = "customize_service.py"

    for root, dirs, files in os.walk(path):
        py_files = list(filter(lambda f: f.endswith('.py'), files))

        if len(py_files) == 1:
            return os.path.join(root, py_files[0])

        elif len(py_files) > 1 and default_service_filename in py_files:
            return os.path.join(root, default_service_filename)

        else:
            raise Exception("can not find custom_service file in {}".format(path))


def load_service_class(model, BaseService):
    service_file_path = get_service_file_path(model.path)
    module = load_source(service_file_path)
    classes = load_classes(module)
    service_class = filter_service_class(classes, BaseService)

    return service_class


def filter_service_class(classes, BaseService):
    class_defs = list(filter(lambda c: issubclass(c, BaseService) and len(c.__subclasses__()) == 0, classes))
    if len(class_defs) != 1:
        raise Exception('no python base service class %s in customize service module file class: %s',
                        BaseService, classes)
    return class_defs[0]


def load_classes(module):
    import inspect
    classes = [cls[1] for cls in inspect.getmembers(module, inspect.isclass)]
    if len(classes) < 1:
        raise Exception('no python service class in customize service module file: %s', module)
    return classes


def load_source(path):
    try:
        name = os.path.splitext(os.path.basename(path))[0]

        if sys.version_info[0] > 2:
            import importlib
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

        else:
            import imp
            module = imp.load_source(name, path)

        return module
    except Exception as e:
        logger.error(e, exc_info=True)
        raise Exception('Incorrect or missing service file: ' + path)


class ModelLoader:
    __metaclass__ = ABCMeta

    @abstractmethod
    def load(self, model):
        pass

    @abstractmethod
    def unload(self, model):
        pass
