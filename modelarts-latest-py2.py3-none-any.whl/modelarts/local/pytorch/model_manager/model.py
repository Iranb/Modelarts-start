import json
import os
import re

regex = re.compile('[^a-zA-Z0-9]')


class Model(object):
    def __init__(self, name, path, remote_path=None, owner=None, gpu=None):
        self._name = name
        self._path = path
        self._remote_path = remote_path
        self._gpu = gpu
        self._owner = owner
        self._metric_name = regex.sub('_', self.name)

    @property
    def name(self):
        return self._name

    @property
    def path(self):
        return self._path

    @property
    def remote_path(self):
        return self._remote_path

    @property
    def gpu(self):
        return self._gpu

    @property
    def owner(self):
        if self._owner is None:
            self._owner = parse_model_owner(self.path)
        return self._owner

    @property
    def metric_name(self):
        return self._metric_name

    def is_owner(self, project_id):
        try:
            if self.owner == project_id:
                return True
            else:
                return False
        except Exception as e:
            return False

    def __str__(self):
        return "model, model_name:%s, model_path: %s, model_owner: %s" % (self.name, self.path, self.owner)


def parse_model_owner(model_path):
    config_path = os.path.join(model_path, '/config.json')

    with open(config_path, 'r') as f:
        model_config = json.load(f)
        return model_config['project_id']
