from .tensorflow_model_loader import TensorflowModelLoader
import log

logger = log.getLogger(__name__)


def scan_all_loader():
    return {
        "tensorflow": TensorflowModelLoader()
    }


class ModelLoaderFactory(object):
    ModelLoaderClassDefList = scan_all_loader()

    @classmethod
    def get_instance(cls, model_type):
        if model_type.lower() not in cls.ModelLoaderClassDefList.keys():
            raise Exception("not supported model type" + str(model_type))

        return cls.ModelLoaderClassDefList[model_type.lower()]
