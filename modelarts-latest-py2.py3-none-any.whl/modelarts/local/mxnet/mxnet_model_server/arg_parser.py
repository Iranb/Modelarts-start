import argparse


class StoreDictKeyPair(argparse.Action):
    """This class is a helper class to parse <model-name>=<model-uri> pairs
    """

    def __call__(self, parser, namespace, values, option_string=None):
        try:
            setattr(namespace, 'models',
                    {kv.split('=', 1)[0]: kv.split('=', 1)[1] for kv in
                     values})
        except Exception:
            raise Exception('Failed to parse <model=path>: ' + str(values) +
                            ' Format should be <model-name>=<model-path> (Local file path, URL, S3).')


class ArgParser(object):
    """Argument parser for mxnet-model-server and mxnet-model-export commands
    More detailed example is available at https://github.com/awslabs/mxnet-model-server/blob/master/README.md
    """

    @staticmethod
    def mms_parser():
        """ Argument parser for mxnet-model-server start service
        """
        parser = argparse.ArgumentParser(prog='mxnet-model-server',
                                         description='MXNet Model Server')

        parser.add_argument('--models',
                            required=True,
                            action=StoreDictKeyPair,
                            metavar='KEY1=VAL1 KEY2=VAL2...',
                            nargs='+',
                            help='Models to be deployed using name=model_location format. '
                                 'Location can be a URL, a local path to a .model file '
                                 'or a folder which contains all files needed for serving.'
                                 'Name is arbitrary and used as the API endpoint\'s base name. ')

        parser.add_argument('--service',
                            help='Path to a user defined model service.')

        parser.add_argument('--gen_api',
                            help='Generates API client for the supplied language. '
                                 'Options include Java, C#, JavaScript and Go. '
                                 'For complete list check out '
                                 'https://github.com/swagger-api/swagger-codegen.')

        parser.add_argument('--port',
                            help='Port number. By default it is 8080.')

        parser.add_argument('--host', help='Host. By default it is localhost.')

        parser.add_argument('--gpu',
                            help='ID of GPU device to use for inference. '
                                 'If your machine has N gpus, this number can be 0 to N - 1. '
                                 'If it is not set, cpu will be used.')

        parser.add_argument('--log_file',
                            help='Log file name. By default it is "mms_app.log" in the current folder.')

        parser.add_argument('--log_rotation_time',
                            help='Log rotation time. By default it is "1 H", which means one Hour. '
                                 'Valid format is "interval when", where _when_ can be "S", "M", "H", or "D". '
                                 'For a particular weekday use only "W0" - "W6". '
                                 'For midnight use only "midnight". '
                                 'Check https://docs.python.org/2/library/logging.handlers.html#logging.handlers.TimedRotatingFileHandler '
                                 'for detailed information on values.')

        parser.add_argument('--log_level',
                            help='Log level. By default it is INFO. '
                                 'Possible values are NOTEST, DEBUG, INFO, ERROR AND CRITICAL. '
                                 'Check https://docs.python.org/2/library/logging.html#logging-levels'
                                 'for detailed information on values.')

        parser.add_argument('--metrics_write_to',
                            default='log',
                            choices=['log', 'csv', 'cloudwatch'],
                            help='By default writes to the Log file specified in `--log_file`.'
                                 'If you pass "csv", various metric files in "csv" format are created in '
                                 'metrics folder in the current directory. '
                                 'If you pass "cloudwatch", metrics will be pushed to AWS CloudWatch Service.')

        parser.add_argument('--load_epoch',
                            required=True,
                            type=int,
                            help='The epoch number of model param file.')

        parser.add_argument('--input_data_name',
                            default='data',
                            type=str,
                            help='Input node name in mxnet symbol.')

        parser.add_argument('--input_data_shape',
                            default='0, 3, 224, 224',
                            type=str,
                            help='Input node shape in mxnet symbol, such as "0, 3, 224, 244".')

        parser.add_argument('--input_type',
                            default='image/jpeg',
                            type=str,
                            help='Input type of service, such as "image/jpeg", "application/json".')

        parser.add_argument('--output_data_name',
                            default='softmax',
                            type=str,
                            help='Output node name in mxnet symbol.')

        parser.add_argument('--output_data_shape',
                            default='0, 1000',
                            type=str,
                            help='Output node shape in mxnet symbol, such as "0, 1000".')

        parser.add_argument('--output_type',
                            default='application/json',
                            type=str,
                            help='Output type of service, such as "image/jpeg", "application/json".')

        return parser

    @staticmethod
    def export_parser():
        """ Argument parser for mxnet-model-export
        """
        parser_export = argparse.ArgumentParser(prog='mxnet-model-export',
                                                description='MXNet Model Export')

        parser_export.add_argument('--model_name',
                                   required=True,
                                   type=str,
                                   help='Exported model name. Exported file will be named as '
                                        'model-name.model and saved in current working directory.')

        parser_export.add_argument('--model_path',
                                   required=True,
                                   type=str,
                                   help='Path to the folder containing model related files. '
                                        'Signature file is required.')

        parser_export.add_argument('--service_file_path',
                                   required=False,
                                   type=str,
                                   default=None,
                                   help='Service file path to handle custom MMS inference logic. '
                                        'if not provided, this tool will package MXNetBaseService if input in signature.json is application/json or '
                                        'MXNetVisionService if input is image/jpeg')

        return parser_export
