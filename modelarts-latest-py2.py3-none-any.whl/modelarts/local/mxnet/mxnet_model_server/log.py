# !/usr/bin/env python

"""Logging utilities."""
import logging
import sys
import warnings
import os

LOG_LEVEL_DICT = {
    "CRITICAL": logging.CRITICAL,
    "ERROR": logging.ERROR,
    "WARNING": logging.WARNING,
    "INFO": logging.INFO,
    "DEBUG": logging.DEBUG,
    "NOTSET": logging.NOTSET
}

PY3 = sys.version_info[0] == 3


class _Formatter(logging.Formatter):
    """Customized log formatter."""

    def __init__(self, colored=True):
        self.colored = colored
        super(_Formatter, self).__init__()

    def _get_color(self, level):
        if logging.WARNING <= level:
            return '\x1b[31m'
        elif logging.INFO <= level:
            return '\x1b[32m'
        return '\x1b[34m'

    def format(self, record):

        fmt = '%(asctime)s [%(threadName)-12.12s] - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
        datefmt = "%Y-%m-%d %H:%M:%S %Z"

        self.datefmt = datefmt

        if PY3:
            self._style._fmt = fmt
        else:
            self._fmt = fmt
        return super(_Formatter, self).format(record)


def getLogger(name=None, filename=None, filemode=None, level='NOTSET'):
    """Gets a customized logger.

    .. note:: `getLogger` is deprecated. Use `get_logger` instead.

    """
    warnings.warn("getLogger is deprecated, Use get_logger instead.",
                  DeprecationWarning, stacklevel=2)
    return get_logger(name, filename, filemode, LOG_LEVEL_DICT[level])


level = logging.NOTSET


consoleHandler = logging.StreamHandler(stream=sys.stdout)
consoleHandler.setFormatter(_Formatter())
consoleHandler.setLevel(level)

root = logging.getLogger()

root.addHandler(consoleHandler)


def get_logger(name=None, filename="/home/mms.log", level="NOTSET",
               rotate_value='H', rotate_interval=1):
    """Gets a customized logger.

    Parameters
    ----------
    name: str, optional
        Name of the logger.
    filename: str, optional
        The filename to which the logger's output will be sent.
    filemode: str, optional
        The file mode to open the file (corresponding to `filename`),
        default is 'a' if `filename` is not ``None``.
    level: int, optional
        The `logging` level for the logger.
        See: https://docs.python.org/2/library/logging.html#logging-levels

    Returns
    -------
    Logger
        A customized `Logger` object.
    """

    logger = logging.getLogger(name)

    logger._init_done = True

    logger.setLevel(level)

    return logger
