#!/usr/bin/python

# -*- coding: utf-8 -*-

import os

mms_args = os.environ['MMS_ARGS'].split()

from mms import mxnet_model_server

app = mxnet_model_server.MMS(app_name='mms', args=mms_args).create_app()
