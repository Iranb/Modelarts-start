#!/bin/bash

current_path=$(cd `dirname $0`;pwd)
model_path=$1
service_port=$2

bash ${current_path}/install.sh

log()
{
    echo "`date "+%Y-%m-%d %T"`: $1"
}

cd ${current_path}

args=" --port ${service_port} "

if [ -z "${model_name}" ]; then
     model_file=$(basename ${model_path}*-symbol.json)
     model_name=${model_file%-symbol*}
fi

if [ ! -f ${model_path}/${model_name}-symbol.json ]; then
    echo "Cannot find ${model_path}/${model_name}-symbol.json"
    exit 1
fi
if [ ! -f ${model_path}/${model_name}-0000.params ]; then
    echo "Cannot find ${model_path}/${model_name}-0000.params"
    exit 1
fi

args=$args" --models ${model_name}=${model_path}"

if [ -z "${load_epoch}" ]; then
    load_epoch=0
fi
args=$args" --load_epoch=${load_epoch}"


if [ -n "${input_data_name}" ]; then
 args=$args" --input_data_name=${input_data_name} "
fi


if [ -n "${input_data_shape}" ]; then
 args=$args" --input_data_shape=${input_data_shape} "
fi


if [ -n "${input_type}" ]; then
 args=$args" --input_type=${input_type} "
fi


if [ -n "${output_data_name}" ]; then
 args=$args" --output_data_name=${output_data_name} "
fi

if [ -n "${output_type}" ]; then
 args=$args" --output_type=${output_type} "
fi

py_file_num=$(ls ${model_path}*.py | wc -l)

service_file=$(ls ${model_path}*.py)

if [ ${py_file_num} -ge 2 ]; then
  service_file=${model_path}customize_service.py
fi

if [ ${py_file_num} -ge 1 ];then
        log "INFO: using service file: ${service_file}"
        args=$args" --service ${service_file} "
    else
        log "WARNING: no service file"
fi

args=$args" --host=0.0.0.0"

log_file=${model_path}log.txt
if [ -f "${log_file}" ]; then
  rm -rf "${log_file}"
fi

cd ${current_path} && MMS_ARGS=$args gunicorn -w 1 -t 120 -b 0.0.0.0:${service_port} app:app | tee ${log_file}