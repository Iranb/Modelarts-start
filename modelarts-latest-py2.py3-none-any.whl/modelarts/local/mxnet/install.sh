#!/bin/bash
# install dls_mxnet_srver

pip_path=`which pip`
current_path=$(cd `dirname $0`;pwd)

mxnet_server_path=$(${pip_path} show mxnet-model-server | grep 'Location')
mxnet_server_path=${mxnet_server_path##*Location: }
mxnet_server_path=$(printf "%s%s" "$mxnet_server_path" "/mms")

echo $current_path
echo $mxnet_server_path
if [ -f $mxnet_server_path/install.log ]; then
    echo "already successfully installed local mxnet-model-server."
    exit 0
fi
cp ${current_path}/mxnet_model_server/arg_parser.py $mxnet_server_path
cp ${current_path}/mxnet_model_server/mxnet_model_server.py $mxnet_server_path
cp ${current_path}/mxnet_model_server/dls_mxnet_model_service.py $(printf "%s%s" "$mxnet_server_path" "/model_service")
cp ${current_path}/mxnet_model_server/dls_faster_rcnn_service.py $(printf "%s%s" "$mxnet_server_path" "/model_service")
cp ${current_path}/mxnet_model_server/dls_segnet_service.py $(printf "%s%s" "$mxnet_server_path" "/model_service")
cp -rf ${current_path}/mxnet_model_server/mxnet_model_service.py $(printf "%s%s" "$mxnet_server_path" "/model_service")
cp -rf ${current_path}/mxnet_model_server/log.py $mxnet_server_path

cp ${current_path}/mxnet_model_server/serving_frontend.py $(printf "%s%s" "$mxnet_server_path" "/")
echo "successfully install local mxnet-model-server."
touch $mxnet_server_path/install.log