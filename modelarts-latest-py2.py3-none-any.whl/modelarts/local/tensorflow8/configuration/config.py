import os

properties = [
    "MODELARTS_TFSERVING_GRPC_PORT"
]


class Config(object):
    MODELARTS_TFSERVING_GRPC_PORT = int(os.getenv("MODELARTS_TFSERVING_GRPC_PORT", 8500))
