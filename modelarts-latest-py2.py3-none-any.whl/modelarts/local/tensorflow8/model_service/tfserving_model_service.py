import tensorflow as tf
from grpc.beta import implementations
from tensorflow import make_tensor_proto
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2

import log
from .model_def import ModelDef
from .model_service import SingleNodeService
from .tfserving_backend import TFServingBackendFactory

logger = log.getLogger(__name__)


class TfServingBaseService(SingleNodeService):

    def __init__(self, model_name, model_path):
        self.model_name = model_name
        self.model_path = model_path
        self.model = ModelDef(model_name, model_path)
        self.tfserving_backend = TFServingBackendFactory.get_instance()
        self.tfserving_backend.load(self.model)
        self.stub = get_tf_server_stub(self.tfserving_backend.port)

    def _inference(self, data):

        request = predict_pb2.PredictRequest()
        request.model_spec.name = 'serve'
        request.model_spec.signature_name = self.model.model_signature

        for k, v in data.items():
            request.inputs[k].CopyFrom(make_tensor_proto(data[k]))

        response = self.stub.Predict(request, 60.0)

        logger.info('predict result : ' + str(response.outputs))

        result = {}

        for output_name in response.outputs:
            tensor_proto = response.outputs[output_name]
            result[output_name] = tf.contrib.util.make_ndarray(tensor_proto).tolist()

        return result

    def _preprocess(self, data):

        return data

    def _postprocess(self, data):

        return data

    def ping(self):
        return

    def signature(self):
        pass

    def __del__(self):
        logger.info("destroy model service %s", self.model.name)
        self.tfserving_backend.unload(self.model)


def __open_tf_server_channel__(server_name, server_port):
    '''
    Opens channel to TensorFlow server for requests

    :param server_name: String, server name (localhost, IP address)
    :param server_port: String, server port
    :return: Channel stub
    '''
    channel = implementations.insecure_channel(
        server_name,
        int(server_port))
    stub = prediction_service_pb2.beta_create_PredictionService_stub(channel)

    return stub


def get_tf_server_stub(server_port):
    server_name = '127.0.0.1'

    logger.info('Connecting to TensorFlow server %s:%s', server_name, server_port)

    # open channel to tensorflow server
    stub = __open_tf_server_channel__(server_name, server_port)
    return stub
