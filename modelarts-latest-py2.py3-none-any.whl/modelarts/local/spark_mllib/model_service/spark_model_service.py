# -*- coding: utf-8 -*-
from .model_service import SingleNodeService
import traceback
import pandas as pd
import json
import collections
from pyspark.ml import Pipeline, PipelineModel
from pyspark.sql import SparkSession

from . import log

logger = log.getLogger(__name__)


class SparkServingBaseService(SingleNodeService):

    def __init__(self, model_path):
        self.model_path = model_path
        # start Spark session
        self.spark = SparkSession.builder.config("spark.driver.host", "localhost").master("local[*]").appName(
            "spark predict").getOrCreate()

    def _preprocess(self, data):
        logger.info("Begin to handle data from user data...")
        # read input
        req_json = json.loads(data, object_pairs_hook=collections.OrderedDict)
        try:
            # preprocess
            predict_spdf = self.spark.createDataFrame(
                pd.DataFrame(req_json["data"]["req_data"]))
        except Exception as e:
            logger.error(
                "check your request data does meet the requirements ?")
            logger.error(traceback.format_exc())
            raise Exception(
                "check your request data does meet the requirements ?")
        return predict_spdf

    def _inference(self, data):
        try:
            # load model
            predict_model = PipelineModel.load(self.model_path)
            # predict
            prediction_result = predict_model.transform(data)
        except Exception as e:
            logger.error(
                "Only support pyspark.ml.PipelineModel by default. User can support other model with their own 'customize_service.py'!")
            logger.error(traceback.format_exc())
            raise Exception(
                "Only support pyspark.ml.PipelineModel by default. User can support other model with their own 'customize_service.py'!")
        return prediction_result

    def _postprocess(self, pre_data):
        logger.info("Get new data to respond...")
        predict_str = pre_data.toPandas().to_json(orient='records')
        predict_result = json.loads(predict_str)
        return predict_result
