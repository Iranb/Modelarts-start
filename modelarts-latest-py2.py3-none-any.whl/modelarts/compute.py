"""Classes used to organzie and submit training tasks."""
import abc
from datetime import datetime
import hashlib
import json
import os
import shutil
from six import with_metaclass
import subprocess
import sys
import time

from semantic_version import Spec, Version

from . import constant
from .environment import const
from .environment import Environment
from .environment.conda_env import CondaDependencies, \
    get_package_name, PYTHON, get_package_version
from .util.path_utils import get_parent_dir
from .util.process_utils import execute_command
from .image_mgmt import ImageManagement
from .swr_mgmt import SWRManagement
from .session import Session
from .util.config import Config


class EnvBuilder(with_metaclass(abc.ABCMeta, object)):
    """Abstract class which aims to build specified code execution
    environment based on Environment object, its implementation can
    build conda environment, docker image and so on.
    """
    @abc.abstractmethod
    def build(self, env):
        """Build code execution environment based on Environment object.

        :param env: Environment object.
        """
        pass


class _CondaLock(object):
    """Inner class used to lock conda environment creation; make sure only
    one conda environment is being created, avoiding parallel conda environment
    operation influences each other: such as disk check, environment-ready
    flag file creation and so on.
    """

    def __init__(self, path):
        """
        Initialize a conda environment lock
        :param path: lock path
        """
        self._path = path

    def __enter__(self):
        lock_duration = 0
        while True:
            try:
                os.makedirs(self._path)
                break
            except OSError:
                pass

            if lock_duration % 3 == 0:
                print("Warning: Waiting for other Conda operations to finish...")
                print("Warning: Delete " + self._path + " to override.\n")
                sys.stdout.flush()
            lock_duration += 1
            time.sleep(1)

    def __exit__(self, type, value, traceback):
        os.rmdir(self._path)


def _get_conda_bin():
    """
    Get conda bin path
    :return conda bin path
    """
    conda_dir = os.environ.get("ANACONDA_DIR")
    return os.path.join(conda_dir, "bin/conda") if conda_dir else const.DEFAULT_CONDA_BIN_PATH


class CondaEnv(EnvBuilder):
    """Build Environment object to a local conda environment."""

    def __get_path(self, conda_env_name):
        """
        get conda environment path
        :return conda environment path
        """
        env_prefix_dir = (os.environ.get(constant.ENVIRONMENT_PATH_ENV_NAME) or
                          constant.DEFAULT_ENVIRONMENT_PATH)
        return os.path.join(env_prefix_dir, conda_env_name)

    def __get_install_lock_dir(self):
        """
        get conda enviroment lock path
        :retrun conda environment lock path
        """
        env_prefix_dir = (os.environ.get(constant.ENVIRONMENT_PATH_ENV_NAME) or
                          constant.DEFAULT_ENVIRONMENT_PATH)
        return os.path.join(get_parent_dir(env_prefix_dir), constant.LOCK_DIR)

    def __is_exist(self, conda_env_name):
        """
        check if the conda environment exists
        :param conda_env_name: conda environment name
        :return true: the conda environment exists
        """
        conda_env_finished = os.path.join(
            self.__get_install_lock_dir(), conda_env_name)
        return (os.path.exists(self.__get_path(conda_env_name)) and
                os.path.exists(conda_env_finished))

    def __generate_yaml(self, conda_dict, conda_env_name):
        """
        Generate a yaml file describing the parameters used to create a conda environment
        :param conda_dict: a dict containing python packages
        :param conda_env_name: conda environment name
        :return the yaml file path
        """
        import yaml
        tmp_conda_env_yaml = os.path.join(
            "/tmp/", "{}.yaml".format(conda_env_name))
        with open(tmp_conda_env_yaml, "w") as f:
            dependencies = []
            dependencies.extend(conda_dict.get(const.CONDA_PACKAGES))
            dependencies.append({"pip": conda_dict.get(const.PIP_PACKAGES)})
            conde_content = {
                "name": conda_env_name,
                "channels": conda_dict.get(const.CHANNELS),
                "dependencies": dependencies,
                "prefix": self.__get_path(conda_env_name)

            }
            yaml.dump(conde_content, f)
        return tmp_conda_env_yaml

    def __remove(self, conda_env_path):
        """
        Remove a conda environment
        :param conda_env_path: conda environment path
        """
        try:
            remove = [
                _get_conda_bin(),
                "env",
                "remove",
                "-y",
                "-p",
                conda_env_path
            ]
            execute_command(remove)
        except subprocess.CalledProcessError as ex:
            print("Warning: Failed to remove conda environment with exit code {}.".format(
                ex.returncode))
        finally:
            if os.path.exists(conda_env_path):
                print("[Cleaning up conda environment directory: {}...]".format(
                    conda_env_path))
                shutil.rmtree(conda_env_path)
                print("[Successfully cleaned up remaining partial conda environment directory: '{}'.]".format(
                    conda_env_path))

    def __create_from_env_file(self, conda_env_path, env_file):
        """
        Create a conda environment according to the environment file
        :param conda_env_path: the conda environment path
        :param env_file: the yaml file containing conda packages
        """
        create_conda_env_command = [
            _get_conda_bin(),
            "env",
            "create",
            "-p",
            conda_env_path,
            "-f",
            env_file
        ]

        try:
            execute_command(create_conda_env_command)
        except subprocess.CalledProcessError:
            self.__remove(conda_env_path)
            raise

    def __clone_and_update(self, conda_env_path, python_env,
                           env_file, conda_dict):
        """
        Clone a conda environment and update it, installing needed packages
        :param conda_env_path: the conda env path
        :param python_env: the python environment path
        :param env_file: the yaml file containing conda packages
        :param conda_dict: packaged needed to install
        """
        clone_conda_env_command = [
            _get_conda_bin(),
            "create",
            "--clone",
            python_env,
            "-p",
            conda_env_path
        ]
        update_conda_env_command = [
            _get_conda_bin(),
            "env",
            "update",
            "--prefix",
            conda_env_path,
            "--file",
            env_file
        ]
        try:
            execute_command(clone_conda_env_command)
            if len(conda_dict.get(const.CONDA_PACKAGES, [])) > 1:
                execute_command(update_conda_env_command)
            else:
                # if there is no other conda packages except python package, we can only
                # install pip packages by pip, avoiding access anacoda channels
                tmp_requirement_txt = "/tmp/" + conda_env_path.split("/")[-1]
                with open(tmp_requirement_txt, "w") as f:
                    for package in conda_dict.get(const.PIP_PACKAGES, []):
                        f.write(package + "\n")
                pip_upgrade_command = [
                    os.path.join(conda_env_path, "bin", "pip"),
                    "install",
                    "--upgrade",
                    "pip"
                ]
                execute_command(pip_upgrade_command)
                pip_install_command = [
                    os.path.join(conda_env_path, "bin", "pip"),
                    "install",
                    "-r",
                    tmp_requirement_txt
                ]
                execute_command(pip_install_command)
        except subprocess.CalledProcessError:
            self.__remove(conda_env_path)
            raise

    def __get_exist_python_env(self, conda_dict):
        """
        Get existing python environment
        :param conda_dict: packages needed
        :return the python environment path
        """
        if not (conda_dict and conda_dict.get("conda-packages")):
            return ""
        python_env_path = ""
        for p in conda_dict.get("conda-packages", []):
            if get_package_name(p) == PYTHON:
                version = get_package_version(p)
                python_env = PYTHON + version
                # We should add agreement in ModelArts document: each conda
                # environment with specified python package should be named
                # as python$version style, whose prefix is DEFAULT_ENVIRONMENT_PATH
                python_env_path = self.__get_path(python_env)
                break
        return python_env_path if os.path.isdir(python_env_path) else ""

    def __create(self, conda_dict, conda_env_name):
        """
        Create a conda environment
        :param conda_dict: packages needed
        :param conda_env_name: conda environemnt name
        """
        conda_env_path = self.__get_path(conda_env_name)
        conda_env_finished = os.path.join(
            self.__get_install_lock_dir(), conda_env_name)

        with _CondaLock(os.path.join(self.__get_install_lock_dir(), constant.ENVIRONMENT_INSTALL_LOCK)):
            if os.path.exists(conda_env_finished):
                shutil.rmtree(conda_env_finished)

            print("[Creating conda environment...]")
            env_file = self.__generate_yaml(
                conda_dict, conda_env_name)
            python_env = self.__get_exist_python_env(conda_dict)
            if python_env:
                # when create a conda environment, a default or specified python package
                # need be installed by conda channel, which need access internet (in some
                # case, modelarts sdk user cannot access internet or it is too slow to access
                # Anacoda channel).
                # however, now Huawei cloud has no inner conda channel, so in ModelArts notebook
                # we can pre-install some python conda environment, when create a new conda
                # environment, we can clone python conda environment and then install pip
                # dependencies to accelerate creating conda environment or avoid accessing
                # internet.
                self.__clone_and_update(
                    conda_env_path, python_env, env_file, conda_dict)
            else:
                self.__create_from_env_file(conda_env_path, env_file)

            os.makedirs(conda_env_finished)
            print("[Conda environment created successfully.]")

    def build(self, env):
        """
        Creating a conda environment. If a conda environment
        with same conda and pip package already exists, we should re-use it.
        :param env: a conda environment
        :return conda environment path
        """
        if not (env and env.conda):
            raise Exception("Invalid Conda environment definition")
        conda_dict = CondaDependencies.serialize_to_dict(env.conda)
        dependencies_str = json.dumps({"conda": conda_dict.get(const.CONDA_PACKAGES) or [],
                                       "pip": conda_dict.get(const.PIP_PACKAGES) or []})

        # Name a conda environment with conda and pip package list MD5 string to make
        # sure re-use conda environment.
        conda_env_name = "modelarts_env_{}".format(hashlib.md5(
            dependencies_str.encode('utf-8')).hexdigest())
        if self.__is_exist(conda_env_name):
            print("[Exsiting Conda environment({}) found to run current task.]".
                  format(self.__get_path(conda_env_name)))
        else:
            self.__create(conda_dict, conda_env_name)
        return self.__get_path(conda_env_name)


class DockerEnv(EnvBuilder):
    """Build docker image based on Environment object."""

    def __match_exsiting_image(self, env):
        """
        If the input docker environment already exists, return docker name
        :param env: a docker environment
        :return docker name or none
        """
        all_envs = Environment.list()
        for existing_env in all_envs:
            if existing_env.docker.image_name and not Environment.diff(existing_env, env):
                return existing_env.docker.image_name
        return None

    def build(self, env):
        """
        This method returns docker image name; since it takes a long time to
        build docker image, we would do our best to reuse docker image which
        can meet current environment requirements.
        """
        docker_image = self.__match_exsiting_image(env)
        if docker_image is not None:
            return docker_image

        if not (env and env.conda):
            raise Exception("Invalid Conda environment definition")

        dockerfile = self.get_dockerfile(env)
        user_swr_org = self.get_namepace()
        # TODO: image name and tag should be meaningful, for example related to
        # job or environment.
        image_name = Config.getenv("IMAGE_NAME")
        image_version = "latest-" + (datetime.now()).strftime('%m%d-%H%M%S')
        pip_config_path = constant.DEFAULT_PIP_CONFIG_PATH
        if constant.USER_PIP_CONFIG_PATH in os.environ:
            pip_config_path = os.environ[constant.USER_PIP_CONFIG_PATH]
            
        shutil.copyfile(pip_config_path,
                        os.path.join(constant.DOCKER_IMAGE_BUILD_DIR, "pip.conf"))

        image = ImageManagement(session=Session(),
                                context="",
                                dockerfile=dockerfile,
                                organization=user_swr_org,
                                name=image_name,
                                version=image_version)

        image.build_push()
        print("Start to build image...")
        result = image.get_log_info()

        # TODO: we need backfill conda/pip installed packages of the
        # built image into env.docker.packages, whose format is like:
        # {"conda":["python=3.6.2",...], "pip": ["tensorflow=1.13.1",...]}

        if result != constant.DOCKER_IMAGE_BUILD_SUCC:
            raise Exception("Failed to build image.")

        docker_image = image.get_swr_location()
        env.docker.image_name = docker_image
        env.docker.dockerfile = dockerfile
        return docker_image
        

    def get_dockerfile(self, env):
        """ See Dockerfile format as below:

            FROM ubuntu:18.04
            COPY /home/ma-user/.pip/pip.conf ~/.pip/pip.conf
            USER work
            RUN  conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free/ && \
                 conda config --set show_channel_urls yes && \
                 pip install numpy tensofflow==2.1 && \
                 conda install Pillow=7.0.0
            USER root
        """

        def save_to_file(file_name, contents):
            with open(file_name, 'w') as f:
                f.write(contents)

        def get_base_image(env):
            if env.docker.base_image:
                return env.docker.base_image
            if "USER_BASE_IMAGE" in os.environ:
                return os.environ["USER_BASE_IMAGE"]
            raise Exception("Base Image is required.")

        conda_dict = CondaDependencies.serialize_to_dict(env.conda)
        conda_channels = " ".join(conda_dict.get(const.CHANNELS) or [])
        conda_packages = " ".join(conda_dict.get(const.CONDA_PACKAGES) or [])
        pip_packages = " ".join(conda_dict.get(const.PIP_PACKAGES) or [])

        # TODO: dockerfile template should be a file format instead of string
        modelfile_name = os.path.dirname(os.path.abspath(__file__)) + "/config/dockerfile_mode"
        with open(modelfile_name, 'r') as f:
            dockerfile_model = f.read()
         
        dockerfile_content = dockerfile_model.format(base_image=get_base_image(env),
                                                     channel=conda_channels,
                                                     proxy=os.environ["PROXY_COMMON"],
                                                     conda_packages=conda_packages,
                                                     pip_packages=pip_packages)
        dockerfile_path = os.path.join(os.getcwd(), "Dockerfile")
        save_to_file(dockerfile_path, dockerfile_content)
        # issue: dockerfile is created in current directory, it may differ from
        # DOCKER_IMAGE_BUILD_DIR
        return dockerfile_path.split(constant.DOCKER_IMAGE_BUILD_DIR)[1]

    def get_namepace(self):

        swr_object = SWRManagement(session=Session())
        org_name = "custom-" + os.environ.get('PROJECT_ID')
        if swr_object.get_namespace(org_name):
            return org_name

        try:
            swr_object.create_namespace(org_name)
        except Exception:
            return swr_object.get_namespace()[0]['name']

        return org_name


def _get_job_name(job_name=None):
    if job_name is not None:
        return job_name
    return 'job-' + (datetime.now()).strftime('%m%d-%H%M%S')


class Data(object):
    """
    Input data object
    """
    def __init__(self,
                 data_source_url=None,
                 local_destination_path=None,
                 overwrite=True):
        """
        Initialize data object.
        :param data_source_url: source data url
        :param local_destination_path: the location where the data will be saved
        :param overwrite: if overwrite data in destination path
        """
        if data_source_url is None:
            raise Exception("Data URL is required.")
        if local_destination_path is None:
            raise Exception(
                "Local path where source data is copied to is required.")
        self.__source_url = data_source_url
        self.__local_dest_path = local_destination_path
        self.__overwrite = overwrite

    @property
    def data_source_url(self):
        return self.__source_url

    @property
    def local_destination_path(self):
        return self.__local_dest_path

    @property
    def overwrite(self):
        return self.__overwrite


class OutputData(object):
    """
    Output data object, including model file, etc.
    """
    def __init__(self,
                 local_path=None,
                 destination_url=None,
                 overwrite=True):
        """
        Initialize the output data object
        :param local_path: local path where the data exists
        :param destination_url: destination URL where the data is uploaded to
        :param overwrite: if overwrite data in destination url
        """
        if local_path is None or destination_url is None:
            raise Exception("Local path or destination URL where the data exists is required.")

        self.__local_path = local_path
        self.__destination_url = destination_url
        self.__overwrite = overwrite

    @property
    def local_path(self):
        return self.__local_path

    @property
    def destination_url(self):
        return self.__destination_url

    @property
    def overwrite(self):
        return self.__overwrite


class RunConfig(object):
    def __init__(self,
                 source_directory=None,
                 boot_file=None,
                 args=None,
                 data=None,
                 output_data=None,
                 instance_count=1,
                 instance_type=None,
                 framework=None):
        """
        The RunConfig object includes all the information which is in need to
        submit a training job or inference job

        :param source_directory: User directory including user source code.
        :type source_directory: str

        :param boot_file: The path of the Python file and the file path is
        relative to the source directory.
        :type boot_file: str

        :param args: Argument list which will be passed to boot_file.
        :type args: List[str]

        :param data: Data information which will be consumed during boot_file runs,
        such as image files in CV task and so on.
        :type data: List[Data]

        :param output_data: Data information which will be uploaded after
        boot_file runs, such as model file and so on.
        :type output_data: List[OutputData]

        :param instance_count: The number of compute instances to use for the task.
        :type instance_count: int

        :param instance_type: The flavor of each compute instance to use for the task.
        :type instance_type: str

        :param framework: The machine learning framework used for the task, such as
        tensorflow, pytorch and so on
        :type framework: str
        """
        self.__source_directory = os.path.abspath(source_directory)
        self.__boot_file = boot_file
        self.__args = args
        self.__data = data
        self.__output_data = output_data
        self.__instance_count = instance_count
        self.__instance_type = instance_type
        self.__framework = framework
        self.__validate()

    def __validate(self):
        """
        check the source code directory and boot file, they are both required
        """
        if (self.__boot_file is None or
                self.__source_directory is None):
            raise Exception(
                "source code directory and boot file are both required.")
        if not os.path.isfile(
                os.path.join(self.__source_directory, self.__boot_file)):
            raise Exception(
                "Cannot find boot file '{}' (relative path to '{}')".format(
                    self.__boot_file, self.__source_directory))

    @property
    def source_directory(self):
        return self.__source_directory

    @property
    def boot_file(self):
        return self.__boot_file

    @property
    def args(self):
        return self.__args

    @property
    def data(self):
        return self.__data

    @property
    def output_data(self):
        return self.__output_data

    @property
    def instance_count(self):
        return self.__instance_count

    @property
    def instance_type(self):
        return self.__instance_type

    @property
    def framework(self):
        return self.__framework


class ModelArtsCompute(with_metaclass(abc.ABCMeta, object)):
    @abc.abstractmethod
    def submit(self, job_name=None):
        pass


class LocalCompute(ModelArtsCompute):
    """Run local source code in a conda environment which meet source
    code dependencies.
    """

    def __init__(self,
                 job_name=None,
                 run_config=None,
                 environment=None,
                 **kwargs):
        """
        initialize local compute environment
        :param job_name: training job name
        :param run_config: an instance including all parameters needed to run a training job
        :param environment: conda or docker environment
        """
        self.__run_config = run_config
        self.__env = environment
        self.__check_runconfig()
        self.__job_name = job_name
        self.env_builder = CondaEnv()
        self.__process = None

    def __check_runconfig(self):
        """
        check run config and env parameters
        """
        if self.__run_config is None:
            raise Exception("run_config is required")
        # TODO: validate other attribution of run_config

        if self.__env is None:
            raise Exception("environment is required.")

    def submit(self, job_name=None):
        """
        submit a local compute job
        :param job_name: training job name
        """
        if job_name is not None:
            self.__job_name = job_name
        conda_env_path = self.env_builder.build(self.__env)

        python_bin = os.path.join(conda_env_path, "bin/python")

        # In training v1 system, it runs boot file under parent directory of
        # code directory, so here in order to keep consistent with training
        # system executing environment, we keep same working directory.
        cwd = get_parent_dir(self.__run_config.source_directory)
        train_command = [
            python_bin,
            "-u",
            (self.__run_config.source_directory[len(cwd)+1:] + "/" +
                self.__run_config.boot_file)
        ]
        if self.__run_config.args:
            train_command.extend(self.__run_config.args)
        self.__log_file = "/tmp/{}.log".format(_get_job_name(self.__job_name))
        with open(self.__log_file, "w") as log_file:
            print("[Start to submit task.]")
            print("[Work directory: {}]".format(cwd))
            print("[Command: {}]".format(" ".join(train_command)))
            environment_variables = self.__env.environment_variables or None
            self.__process = subprocess.Popen(train_command,
                                              stdout=log_file,
                                              stderr=log_file,
                                              close_fds=False,
                                              env=environment_variables,
                                              cwd=cwd)
            print("[Task submitted.]")
        self.__wait_for_finished(show_output=True)

    def __wait_for_finished(self, show_output=True):
        """
        Wait for the job done and print logs
        :param show_output: if print logs
        """
        finished_status = [
            const.TASK_UNKNOWN_INDEX,
            const.TASK_TASK_COMPLETED_INDEX,
            const.TASK_TASK_FAILED_INDEX
        ]
        printed_lines = 0
        while True:
            status = self.__get_job_status()
            if show_output:
                with open(self.__log_file, "r") as f:
                    lines = f.readlines()
                    if len(lines) > printed_lines:
                        for line in lines[printed_lines:]:
                            sys.stdout.write(line)
                        sys.stdout.flush()
                        printed_lines = len(lines)
            else:
                print("[Task status: {} ...]".format(
                    const.TASK_STATES[status]))

            if status in finished_status:
                break
            time.sleep(1)

        print("[Task done with status {}.]".format(
            const.TASK_STATES[self.__get_job_status()]))

    def __get_job_status(self):
        """
        Get training task working status
        :return working status
        """
        if self.__process is None:
            return const.TASK_UNKNOWN_INDEX
        if self.__process.returncode is None:
            self.__process.poll()

        if self.__process.returncode is None:
            return const.TASK_TASK_RUNNING_INDEX
        if self.__process.returncode == 0:
            return const.TASK_TASK_COMPLETED_INDEX
        return const.TASK_TASK_FAILED_INDEX


class TrainV1Compute(ModelArtsCompute):
    """Submit a v1 training job based on environment object, local source code
    and so on.
    """
    FRAMEWORK_ALIAS = {
        "tf": ["tensorflow", "tensorflow-gpu"],
        "spark": ["pyspark"],
        "pytorch": ["torch"],
        "sklearn": ["scikit-learn"],
        "mxnet": ["mxnet-cu90", "mxnet"]
    }

    def __init__(self,
                 job_name=None,
                 run_config=None,
                 environment=None,
                 estimator=None,
                 **kwargs):
        """
        Initialize a V1 compute environment object
        :param job_name: job name
        :param run_config: an instance including all parameters needed to run a training job
        :param environment: a conda or docker environment
        :param estimator: an estimator
        """
        self.__run_config = run_config
        self.__job_name = job_name
        self.__env = environment
        self.__estimator = estimator
        # self.env_builder = DockerEnv()
        self.__validate()

    def __validate(self):
        """
        Validate compute parameters
        """
        if self.__env.environment_variables:
            raise Exception(
                ("ModelArts training v1 version doesn't support environment "
                 "variables; you can use argument option in your program instead."))
        if len(self.__env.conda.conda_packages) > 1:
            # python conda package is aways in conda_packages; for other conda packages,
            # modelarts v1 training system doesn't support install conda package on time.
            raise Exception(
                ("ModelArts training v1 version doesn't support conda dependencies;"
                 " you can try pip dependencies instead."))
        args_length = len(self.__run_config.args)
        if args_length % 2 != 0:
            raise Exception(
                "ModelArts training v1 version only supports parameter with key-value pair.")

    def __prepare_source_code(self):
        """
        Upload needed packages and training file into obs
        """
        pip_requirement_txt = os.path.join(
            os.path.dirname(os.path.join(
                self.__run_config.source_directory, self.__run_config.boot_file)),
            "pip-requirements.txt")
        with open(pip_requirement_txt, "w") as f:
            for pip_package in self.__env.conda.pip_packages or []:
                f.write(pip_package + "\n")
        print("[Start to upload source directory to default OBS bucket.]")
        bucket_name = self.__estimator.modelarts_session.default_bucket()
        base_bucket_path = '/' + bucket_name + '/' + self.__job_name
        self.__estimator.modelarts_session.upload_data(
            base_bucket_path, self.__run_config.source_directory)
        print("[Upload source directory to default OBS bucket successfully.]")

        code_dir = self.__run_config.source_directory.split("/")[-1]
        app_url = os.path.join(base_bucket_path, code_dir) + "/"
        boot_url = app_url + self.__run_config.boot_file
        self.__estimator.code_dir = app_url
        self.__estimator.boot_file = boot_url

    def __construct_framework(self):
        """
        Organize the supported frameworks into a map
        framwork_list looks like below:
        [
         {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.4.0-python3.6'},
         {'framework_type': 'TensorFlow', 'framework_version': 'TF-2.1.0-python3.6'},
         {'framework_type': 'XGBoost-Sklearn',
          'framework_version': 'XGBoost-0.80-Sklearn-0.18.1-python2.7'},
         ...
        ]
        """
        framwork_list = self.__estimator.get_framework_list(
            self.__estimator.modelarts_session)
        support_framework_map = {}
        for framework in framwork_list:
            # KungFu is a placeholder, cannot work now
            if (framework['framework_type'] == "KungFu" or
                    "kungfu" in framework['framework_version'].lower()):
                continue
            f_version = framework['framework_version']
            f_version_array = f_version.split("-")
            if not f_version_array[-1].startswith(PYTHON):
                continue
            pythonversion = f_version_array[-1][len(PYTHON):]
            for i in range(0, len(f_version_array)-1, 2):
                framework_name = f_version_array[i].lower()
                framework_version = f_version_array[i+1]
                f_name_list = (TrainV1Compute.FRAMEWORK_ALIAS.get(framework_name) or
                               [framework_name])
                for f_name in f_name_list:
                    if f_name not in support_framework_map:
                        support_framework_map[f_name] = []
                    support_framework_map[f_name].append(
                        {
                            "version": framework_version,
                            "python": pythonversion,
                            "framework_type": framework['framework_type'],
                            "framework_version": framework['framework_version']
                        }
                    )
        return support_framework_map

    def __prepare_framework(self):
        """
        Prepare calculation framework which satisfy the input condition
        """
        python_verison = Version.coerce(self.__env.conda.get_python_version())
        python_version_str = "{}.{}".format(
            python_verison.major, python_verison.minor)
        match = False
        support_framework_map = self.__construct_framework()
        for p in self.__env.conda.pip_packages:
            p_name = get_package_name(p).lower()
            if p_name not in support_framework_map:
                continue
            framework_list = support_framework_map[p_name]
            for framework in framework_list:
                if python_version_str != framework["python"]:
                    continue
                spec = p[len(p_name):].strip()
                if spec and (not Spec(spec).match(Version.coerce(framework["version"]))):
                    continue

                self.__estimator.framework_type = framework["framework_type"]
                self.__estimator.framework_version = framework["framework_version"]
                match = True
                break
            if match:
                break
        else:
            info = ""
            for framekwork in support_framework_map:
                info += "\n{}:".format(framekwork)
                for v in support_framework_map[framekwork]:
                    info += "\n    version: {}; python version: {}".format(
                        v["version"], v["python"])
            raise Exception("Frameworks supported as below: \n" + info)

    def __prepare_parameter(self):
        """
        Prepare hyperparameters for the algorithm
        """
        if not self.__run_config.args:
            return

        parameters = []
        args_length = len(self.__run_config.args)
        for i in range(int(args_length / 2)):
            label = self.__run_config.args[i*2]
            if label.startswith("--"):
                label = label[2:]
            parameters.append({
                'label': label,
                'value': self.__run_config.args[i*2+1],
            })
        self.__estimator.hyperparameters = parameters

    def __prepare_config(self):
        """
        Prepare V1 compute config
        """
        self.__prepare_parameter()
        self.__prepare_framework()
        self.__prepare_source_code()

    def submit(self, job_name=None):
        """
        Submit a training job
        :param job_name: job name
        """
        if job_name is not None:
            self.__job_name = job_name
        self.__prepare_config()
        job_train_resp = self.__estimator.start_new(None, None, None, None)
        job_train_resp = self.__estimator.trainingJob._transform_roma_response(
            job_train_resp)
        if not job_train_resp['is_success']:
            raise Exception(
                'Failed to create the job with the error_code %s and error_msg %s .'
                % (job_train_resp['error_code'], job_train_resp['error_msg']))

        console_url = (os.environ["MODELARTS_CONSOLE_ENDPOINT"] or
                       "https://console.huaweicloud.com/modelarts/?region={}".format(
            self.__estimator.modelarts_session.region_name))
        job_url = "{}#/trainingJobs/{}/detail".format(
            console_url, job_train_resp['job_id'])
        print(
            "[Training job submitted! Check '{}' for job information.]".format(job_url))
        return job_train_resp


class TrainV2Compute(ModelArtsCompute):
    """Submit a v1 training job based on environment object, local source code
    and so on. For v2 training job, we can enhance user experience by shared
    storage (for now, it is EFS, and ModelArts notebook and training job share same
    EFS).
    """

    def __init__(self,
                 job_name=None,
                 environment=None,
                 **kwargs):

        self.env_builder = DockerEnv()

    def submit(self, job_name=None):
        docker_image = self.env_builder.build(self.env)
        # TODO: submit training job
