import os
import re
import logging
import json
import hashlib
import shutil
from .config import config
from .util.obs_util import OBS
from .util.config import Config
from modelarts import constant
import urllib3
from .util.secret_util import auth_expired_handler, read_ak_sk_from_secret
from .obs_mgmt import OBSManagement

urllib3.disable_warnings()
logging.basicConfig()
LOGGER = logging.getLogger('modelarts-sdk')
LOGGER.setLevel(logging.INFO)
MODELARTS_CONFIG = os.getenv("MODELARTS_CONFIG",
                             constant.MODELARTS_CONFIG_PATH)


class Session(object):
    """Manage interactions with the HUAWEIYUN services needed.
    This class provides convenient methods for manipulating other services,
    such as iam auth, operation in OBS.
    """

    hcs_environment_valid = False

    def __init__(self, config_file=None, username=None, password=None,
                 access_key=None, secret_key=None,
                 region_name=None, account=None, project_id=None, app_id=None,
                 app_token=None, w3_account=None,
                 w3_password=None):
        """
        Initialize a ModelArts ``Session``.
        :param config_file:
        :param username:
        :param password:
        :param access_key: obs ak
        :param secret_key: obs sk
        :param region_name: region such as cn-north-1
        :param account:
        :param project_id:
        :param app_id:
        :param app_token:
        :param w3_account:
        :param w3_password:
        """
        self.user_id = None
        self.security_token = None

        if app_id and w3_account or app_token and w3_password:
            self._init_roma(region_name, app_id, app_token, w3_account,
                            w3_password)
        else:
            self._init_config_file(config_file)
            self._init_username_password(account, username, password)
            self._init_region_name(region_name)

            if self.__is_account_auth(username, password):
                self._init_account(username, password)
            elif self.__is_aksk_auth(access_key, secret_key):
                self._init_ak_sk(access_key, secret_key)
            else:
                self._init_account(username, password)

            self._init_project_id(project_id)

    def __is_account_auth(self, username=None, password=None):
        """
        If user authentication by username and account.
        :param username: user name
        :param password: password
        :return True of False
        """
        return username and password and not self.config_file_auth

    def __is_aksk_auth(self, access_key=None, secret_key=None):
        """
        If user authentication by aksk.
        :param access_key: access key
        :param secret_key: secret key
        :return True of False
        """
        return (access_key and secret_key) or self._is_notebook_environ() or self._is_train_environ()

    def _init_roma(self, region_name, app_id, app_token, w3_account,
                   w3_password):
        """
        :param region_name: region name
        :param app_id: app_id of roma application
        :param app_token: app_token of roma application
        :param w3_account: w3 account
        :param w3_password: w3 password
        """
        self.auth = constant.ROMA_AUTH
        self.host = constant.ROMA_HOST
        self.project_id = constant.ROMA_PROJECT_ID

        if not region_name:
            raise ValueError('Parameter region_name is needed')
        self.region_name = region_name
        if self.region_name not in constant.SUPPORTED_REGION:
            raise ValueError('Region_name should be {}.'.format(constant.SUPPORTED_REGION))

        self.headers = {
            "Content-Type": constant.ROMA_CONTENT_TYPE,
            "Region": region_name,
            "App-ID": app_id,
            "W3-Account": w3_account
            }
        if app_token:
            self.headers["App-Token"] = app_token
        if w3_password:
            self.headers["W3-Password"] = w3_password

        if app_id and app_token:
            self.obs = OBSManagement(app_id=app_id, app_token=app_token, region_name=region_name)
        else:
            print("Warning: roma obs management can not operate, it need app_id and app_token.")
            self.obs = None

    def _init_ak_sk(self, access_key, secret_key):
        if access_key and secret_key:
            self.access_key = access_key
            self.secret_key = secret_key
        else:
            self.access_key, self.secret_key, self.security_token, self.user_id = read_ak_sk_from_secret()

        self.auth = constant.AKSK_AUTH
        self.obs_client = OBS(server=self.obs_server, ak=self.access_key,
                              sk=self.secret_key, security_token=self.security_token)
        self.client = config.create_client(context="default",
                                           access_key=self.access_key,
                                           secret_key=self.secret_key,
                                           region_name=self.region_name,
                                           customize_config=self.hcs_environment_valid)

        self.obs = OBSManagement(server=self.obs_server, ak=self.access_key,
                                 sk=self.secret_key, security_token=self.security_token)

    def _init_account(self, username, password):
        self.auth = constant.ACCOUNT_AUTH
        token, project_id = config.authorize_by_token(username=self.username,
                                                      password=self.password,
                                                      account=self.account,
                                                      region=self.region_name,
                                                      endpoint=self.iam_server)
        res = config.get_temporary_aksk_without_agency(token, self.iam_server)
        self.access_key = res.json()['credential']['access']
        self.secret_key = res.json()['credential']['secret']
        security_token = res.json()['credential']['securitytoken']
        self.obs_client = OBS(server=self.obs_server, ak=self.access_key,
                              sk=self.secret_key,
                              security_token=security_token)

        self.obs = OBSManagement(server=self.obs_server, ak=self.access_key,
                                 sk=self.secret_key,
                                 security_token=security_token)

        if username and password:
            self.client = config.create_client(context="default",
                                               username=self.username,
                                               password=self.password,
                                               account=self.account,
                                               region_name=self.region_name,
                                               customize_config=self.hcs_environment_valid)
        else:
            self.client = config.create_client(config_file=self.config_file,
                                               context="default",
                                               region_name=self.region_name,
                                               customize_config=self.hcs_environment_valid)

    def _init_config_file(self, config_file):
        """
        :param config_file: ~/.modelarts/config.json
        """
        if config_file:
            self.config_file = config_file
        elif os.path.exists(os.path.expanduser(MODELARTS_CONFIG)):
            self.config_file = os.path.expanduser(MODELARTS_CONFIG)
        else:
            config_dir = os.path.expanduser(
                constant.MODELARTS_CONFIG_PATH.rsplit('/', 1)[0])
            if not os.path.exists(config_dir):
                os.makedirs(config_dir)
            shutil.copyfile(os.path.dirname(config.__file__) + '/' +
                            constant.MODELARTS_CONFIG_PATH.rsplit('/', 1)[1],
                            os.path.expanduser(MODELARTS_CONFIG))
            self.config_file = os.path.expanduser(MODELARTS_CONFIG)

    def _init_region_name(self, region_name):
        """
        several scenario
        p1. iam\obs\modelarts endpoint configured in config.ini
        p2. notebook environment and iam_endpoint in environ
        :param region_name: region name
        :return:
        """
        if region_name:
            self.region_name = region_name
        elif "REGION_NAME" in os.environ:
            self.region_name = os.environ["REGION_NAME"]
        elif "S3_REGION" in os.environ:
            self.region_name = os.environ["S3_REGION"]
        else:
            with open(self.config_file) as f:
                config_json = json.load(f)
                self.region_name = config_json['clusters'][0]['cluster']['region']

        if self.region_name in constant.SUPPORTED_REGION:
            self.obs_server = Config.getenv("OBS_" + self.region_name)
            self.iam_server = Config.getenv("IAM_" + self.region_name)
            self.host = Config.getenv("MODELARTS_" + self.region_name)

        elif self._is_notebook_environ() and \
                (os.environ.get('IAM_ENDPOINT') is not None):
            self.obs_server = config.remove_protocol(os.environ["S3_ENDPOINT"])
            self.iam_server = config.remove_protocol(os.environ["IAM_ENDPOINT"])
            self.host = config.remove_protocol(
                self.obs_server.replace("obs", "modelarts"))
        # hsc environment, without notebook to use sdk
        elif self.hcs_environment_valid:
            self.obs_server = os.environ["S3_ENDPOINT"]
            self.iam_server = os.environ["IAM_ENDPOINT"]
            self.host = os.environ["MA_ENDPOINT"]
        else:
            raise ValueError('Unrecognized region name of {}'.
                             format(region_name))

    def _init_username_password(self, account, username, password):
        """
        :param account: iam account
        :param username: iam username
        :param password: iam password
        :return:
        """
        if username and password:
            self.config_file_auth = False
            self.account = account
            self.username = username
            self.password = password
        else:
            self.config_file_auth = True
            with open(self.config_file) as f:
                config_json = json.load(f)
                user_info = config_json['users'][0]['user']
                self.account = user_info['account'] if 'account' in user_info else None
                self.username = user_info['username']
                self.password = user_info['password']

    def _init_project_id(self, project_id):
        """
        :param project_id: iam project_id
        :return:
        """
        if project_id:
            self.project_id = project_id
        elif "PROJECT_ID" in os.environ:
            self.project_id = os.environ["PROJECT_ID"]
        elif "project_id" in os.environ:
            self.project_id = os.environ["project_id"]
        else:
            raise Exception('project_id is required for init session')

    def _is_notebook_environ(self):
        """  check if it is ma_notebook environment
        :return: True or False
        """
        return True if ("CREDENTIAL_PROFILES_FILE" in os.environ or "AWS_CREDENTIAL_PROFILES_FILE"
                        in os.environ) and "NB_USER" in os.environ else False

    def _is_train_environ(self):
        """  check if it is ma_train environment
        :return: True or False
        """
        return "AWS_SHARED_CREDENTIALS_FILE" in os.environ

    @staticmethod
    def set_domain(name, value):
        """
        Set value to environment variable.
        :param name: environment variable name.
        :param value: environment variable value.
        """
        if value:
            if not value.startswith("https"):
                raise ValueError("Parameter {} should start with https.".format(value))
            else:
                domain = value.split("//")[1]
                if re.match(constant.DOMAIN_PATTERN, domain):
                    os.environ[name] = domain
                else:
                    raise ValueError("Please input valid value of param {}.".format(value))
        else:
            raise ValueError("Parameter is empty.")

    @classmethod
    def set_endpoint(cls, iam_endpoint="", obs_endpoint="",
                     modelarts_endpoint="", region_name="",
                     **kwargs):
        """
        Set sdk related service endpoint.
        :param iam_endpoint: iam endpoint.
        :param obs_endpoint: obs endpoint.
        :param swr_endpoint: swr endpoint.
        :param modelarts_endpoint: modelarts endpoint.
        :param region_name: region name.
        """
        cls.set_domain('IAM_ENDPOINT', iam_endpoint)
        cls.set_domain('S3_ENDPOINT', obs_endpoint)
        cls.set_domain('MA_ENDPOINT', modelarts_endpoint)
        if region_name:
            os.environ['REGION_NAME'] = region_name
        else:
            raise ValueError("region_name is invalid: {}.".format(region_name))
        if 'swr_endpoint' in kwargs:
            cls.set_domain('IMAGE_REPO_URL', kwargs['swr_endpoint'])
        cls.hcs_environment_valid = True

    @auth_expired_handler
    def get_obs_client(self):
        """ Get OBS client for OBS operation
        :return: OBS client
        """
        return self.obs_client.get_obs_client()

    @auth_expired_handler
    def create_bucket(self, bucket):
        """ Create OBS bucket to use in relevant ModelArts interactions.
        :param bucket:
        :return: str: obs bucket
        """
        return self.obs_client.create_bucket(bucket_name=bucket,
                                             location=self.region_name)

    @auth_expired_handler
    def default_bucket(self, bucket=None):
        """
        Return the name of the default OBS bucket to use
        in relevant ModelArts interactions.
        :param bucket: obs bucket
        :return: str: The name of the default bucket,
        which is of the form: ``auto-job-{timestamp}``.
        """
        if bucket:
            return self.obs_client.create_bucket(bucket_name=bucket,
                                                 location=self.region_name)
        else:
            project_id_md5 = hashlib.md5(
                self.project_id.encode('utf-8')).hexdigest()[:8]
            default_bucket = 'modelarts-{}-{}'.format(self.region_name,
                                                      project_id_md5)
            return self.obs_client.create_bucket(bucket_name=default_bucket,
                                                 location=self.region_name)

    @auth_expired_handler
    def upload_data(self, bucket_path, path):
        """
        Upload local file or directory to obs.
        :param bucket_path: obs bucket path
        :param path: local file path, such as /opt/test/a.txt
        :return:
        """
        bucket_path = self.obs_client.check_bucket_path(bucket_path)
        if isinstance(path, list):
            self.obs_client.put_multi_objects(bucket_path=bucket_path,
                                              local_file_paths=path)
        elif isinstance(path, str):
            if not os.path.exists(path):
                raise Exception("Path " + path + " does not exist!")
            if os.path.isdir(path):
                self.obs_client.put_directory(bucket_path=bucket_path,
                                              local_directory_path=path)
            elif os.path.isfile(path):
                self.obs_client.put_object(bucket_path=bucket_path,
                                           local_file_path=path)
            print(
                "Successfully upload file %s to OBS %s" % (path, bucket_path))
        else:
            raise Exception('local path should be list or string')

    @auth_expired_handler
    def download_data(self, bucket_path, path, subfiles_mode=False):
        """
        :param bucket_path: obs bucket path
        :param path: local file path, such as /opt/test/a.txt
        :param subfiles_mode: whether download files of directory or not
        :return:
        """
        if not os.path.exists(path) and not os.path.exists(
                os.path.abspath(os.path.dirname(path))):
            raise Exception("Path " + path + " does not exist!")
        is_directory = bucket_path.endswith('/')
        bucket_path = self.obs_client.check_bucket_path(bucket_path)
        if is_directory:
            object_name = bucket_path.split('/', 1)[1] + '/'
            obs_objects = self.obs_client.list_all_objects(
                bucket_path.split('/', 1)[0], object_name)
            is_exist = any(obj.startswith(object_name) for obj in obs_objects)
            if not is_exist:
                raise Exception(
                    "OBS bucket path does not exist, please check it! ")

            bucket_path = bucket_path.rstrip('/')
            local_storage_path = path.rstrip('/')
            if not subfiles_mode:
                local_storage_path = local_storage_path + '/' + \
                                     bucket_path.split('/')[-1]
            self.obs_client.download_directory(bucket_path=bucket_path,
                                               local_storage_path=local_storage_path)
        else:
            self.obs_client.download_object(bucket_path=bucket_path,
                                            local_file_path=path)
        print("Successfully download file %s from OBS to local %s" % (
            bucket_path, path))

    @auth_expired_handler
    def delete_bucket(self, bucket):
        """
        :param bucket: obs bucket
        :return:
        """
        if self.obs_client.delete_objects(bucket):
            self.obs_client.delete_bucket(bucket)

    @auth_expired_handler
    def create_directory(self, bucket, directory):
        """
        :param bucket: obs bucket
        :param directory: local directory, such as /opt/test
        :return:
        """
        self.obs_client.create_directory(bucket, directory)
