"""
Description: Huawei Cloud image management create auth, build and push image
Author: ModelArts SDK Team
Date: 2020/10/01 - 2020/10/30
"""

import os
import requests
from .util.config import Config
from .config.auth import auth_by_apig
from threading import Thread
import time
from hashlib import sha1
from . import constant


def _async_call(fn):
    def wrapper(*args, **kwargs):
        Thread(target=fn, args=args, kwargs=kwargs).start()

    return wrapper


class ImageManagement(object):

    def __init__(self, session, dockerfile, organization=None, name=None, version=None,
                 context=None):

        """
        Initialize a image builder , determine the attributes of the image build.
        :param session: Building interactions with HUAWEI Cloud service.
        :param dockerfile: dockerfile path
        :param organization: image item organization
        :param name: image product name
        :param version: image product version
        :param context: relative path of image build
        """
        if os.environ.get('IMAGE_REPO_URL') is None:
            raise Exception("The function of building image only applies to Modelarts Notebook.")

        self.session = session
        self.context = context
        self.dockerfile = dockerfile
        self.organization = organization
        self.name = "docker_image" if name is None else name
        self.version = "latest" if version is None else version
        self.region_name = os.environ.get('REGION_NAME')
        self.repo_url = os.environ.get('IMAGE_REPO_URL')
        self.proxies = {'http': None, 'https': None}
        self.local_host = "http://{}/".format(Config.getenv("IMAGE_LOCAL_HOST"))
        self.init_auth()
        session_id = sha1(str(time.time()).encode('utf-8'))
        self.session_id = session_id.hexdigest()

    def init_auth(self):

        """ Send a request to another container to init swr auth
        """
        try:
            swr_auth = self.get_swr_auth()
        except Exception as e:
            raise Exception('Failed to init swr auth. The reason is : %s' % e)

        request_info = {'auth': str(swr_auth)}
        request_url = self.local_host + "init"
        requests.post(request_url, data=request_info, proxies=self.proxies)

    def get_swr_auth(self):

        """ Send a request to swr service to get auth
        """

        request_url = '/v2/manage/utils/secret'
        swr_host = "swr-api" + self.repo_url.split("swr")[1]
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url)

    def create_auth(self, access_key, secret_key):

        """ Send a request to another container to create auth
        """
        user_info = {'repository': self.repo_url, 'ak': access_key, 'sk': secret_key, 'region_name': self.region_name}
        init_request_url = self.local_host + "init"
        requests.post(init_request_url, data=user_info, proxies=self.proxies)

    @_async_call
    def build_push(self):

        """ Send a request to another container to build image
        :return: image build result
        """

        build_request_url = self.local_host + "build"
        build_info = {
            'context': self.context,
            'dockerfile': self.dockerfile,
            'registry': self.repo_url,
            'organization': self.organization,
            'name': self.name,
            'version': self.version,
            'session_id': self.session_id
        }

        requests.post(build_request_url, data=build_info, proxies=self.proxies)

    def log_minot(self, log_file):

        """ Monitor and generate logs.
        """
        import inotify.adapters
        inot_event = inotify.adapters.Inotify()
        inot_event.add_watch(
            log_file,
            mask=inotify.constants.IN_MODIFY
        )

        with open(log_file) as fd:
            for event in inot_event.event_gen():
                line = fd.readline()
                if ("Construction End" in line):
                    return line.split("Construction End:")[1]
                print(line)

    def get_log_info(self):

        """  Check whether the log file exists
        """
        start = time.time()
        log_file = "/home/ma-user/work/" + ".build-" + self.session_id + ".log"
        while True:
            if os.path.exists(log_file):
                res = self.log_minot(log_file)
                return res
            end = time.time()
            if (end - start > constant.DOCKER_IMAGE_BUILD_MAX_TIME):
                raise Exception("Start task build failed.")

    def get_swr_location(self):

        """
        :return: output image url
        """
        return "{}/{}/{}:{}".format(self.repo_url, self.organization, self.name, self.version)
