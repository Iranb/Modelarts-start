"""
Dataset SDK for ModelArts dataset management.
"""

import json
import os
import tempfile
import time

from modelarts import constant

from modelarts.dataset.csv_handler import CsvReader
from modelarts.dataset.dataset_impl import DatasetApiAKSKImpl, ManagedStorage


class Dataset(object):
    """
    A ModelArts Dataset that can create dataset, get dataset information and list,
    update dataset, delete dataset, publish dataset version, get dataset verion information and list,
    get structured dataset schema, batch read the specified version of structured dataset,
    import dataset and export dataset.
    """

    def __init__(self, session, dataset_id=None, headers=None):
        """
        Initialize a ModelArts Dataset, determine the dataset authorize type.
        :param session: Building interactions with HUAWEI Cloud service
        :param dataset_id: dataset id
        """
        if constant.AKSK_AUTH != session.auth:
            raise Exception("Only AK SK authentication supported.")
        self.session = session
        self.dataset_id = dataset_id
        if not self.session.security_token:
            self.dataset_instance = DatasetApiAKSKImpl(self.session, headers)
        else:
            self.dataset_instance = DatasetApiAKSKImpl(self.session)

    def __check_dataset_id(self, dataset_id=None):
        """
        check and get valid dataset id.
        :param dataset_id: dataset id
        :return: dataset id
        """
        if not dataset_id and not self.dataset_id:
            raise ValueError("Dataset id is needed.")
        return dataset_id if dataset_id else self.dataset_id

    @staticmethod
    def __check_field(schema_field):
        """
        check field parameters of schema when creating structured dataset.
        :param schema_field: each field of schema
        """
        if any(key not in ['schema_id', 'name', 'type'] for key in schema_field):
            raise ValueError("schema_id, name, type is needed in each field of schema.")

    @classmethod
    def get_dataset_list(cls, session, offset=None, limit=None, dataset_type=None):
        """
        get dataset list.
        :param session: Building interactions with HUAWEI Cloud service
        :return: response of getting dataset list, including dataset total number and dataset list
        """
        dataset = Dataset(session)
        return dataset.__get_dataset_list_by_instance(offset=offset, limit=limit, dataset_type=dataset_type)

    def __get_dataset_list_by_instance(self, offset, limit, dataset_type):
        """
        get dataset list by dataset instance with one authorize type.
        :return: response of getting dataset list
        """
        return self.dataset_instance.get_dataset_list(offset, limit, dataset_type)

    @classmethod
    def create_dataset(cls, session, dataset_name=None, dataset_type=None, data_sources=None, import_data=None,
                       schema=None, storage=None, description=None):
        """
        create dataset.
        :param session: Building interactions with HUAWEI Cloud service.
        :param dataset_name: dataset name
        :param dataset_type: dataset type
        :param data_sources: list of data_source, including data_type and data_path
        :param import_data: whether to import data when creating dataset
        :param schema: structured dataset schema
        :param storage: dataset storaged information, including managed, which indicates whether the dataset is hosted,
                        work_path, which indicates the OBS path of dataset,
                        work_path_type, which indicates the type of work_path, currently only support OBS path.
        :param description: dataset description
        :return: response of creating dataset, including dataset_id
        """
        create_dataset_body = dict()
        if not dataset_name:
            raise ValueError('The dataset_name is required.')
        create_dataset_body['dataset_name'] = dataset_name

        if not dataset_type:
            raise ValueError('The dataset_type is required.')
        create_dataset_body['dataset_type'] = dataset_type

        if data_sources:
            create_dataset_body['data_sources'] = data_sources

        if dataset_type == constant.DATASET_TYPE_TABULAR:
            if (not schema) or (not isinstance(schema, list)):
                raise ValueError('The schema is required and should be list.')
            for field in schema:
                cls.__check_field(field)
            create_dataset_body['schema'] = schema

        if not storage:
            raise ValueError('The storage is required.')
        create_dataset_body['managed'] = "true" if storage.managed else "false"
        create_dataset_body['work_path'] = storage.work_path
        create_dataset_body['work_path_type'] = storage.work_path_type

        if description:
            create_dataset_body['description'] = description

        create_dataset_body['import_data'] = "true" if import_data else "false"

        dataset = Dataset(session)
        return dataset.__create_dataset_with_body(create_dataset_body)

    def __create_dataset_with_body(self, create_dataset_body):
        """
        create dataset by dataset instance with one authorize type.
        :return: response of creating dataset, including dataset id
        """
        return self.dataset_instance.create_dataset(create_dataset_body)

    @classmethod
    def delete_dataset(cls, session, dataset_id):
        """
        delete dataset.
        :param session: Building interactions with HUAWEI Cloud service
        :param dataset_id: dataset id
        :return: response of deleting dataset
        """
        dataset = Dataset(session, dataset_id)
        return dataset.__delete_dataset_by_id(dataset_id)

    @classmethod
    def get_dataframe(cls, session, dataset_name, version_name):
        dataset_id = cls._get_dataset_id(session, dataset_name)
        version_id = cls._get_version_id(session, dataset_id, version_name)
        if not version_id:
            raise ValueError("Version is invalid.")
        dataset = Dataset(session, dataset_id)
        reader = dataset.create_reader(version_id=version_id)
        dataframe = reader.read_full_data()
        reader.close()
        dataset_info = dataset.get_dataset_info()
        # dataframe.columns = list(map(lambda item: item['name'], dataset_info['schema']))
        dataframe.columns = [item['name'] for item in dataset_info['schema']]
        return dataframe

    @classmethod
    def _get_dataset_id(cls, session, dataset_name):
        page_no = 0

        while True:
            dataset_list_resp = Dataset.get_dataset_list(session, offset=page_no, limit=10,
                                                         dataset_type=constant.DATASET_TYPE_TABULAR)
            dataset_list = dataset_list_resp['datasets']

            if not dataset_list:
                return None
            page_no += 1

            for dataset_item in dataset_list:
                if dataset_item["dataset_name"] == dataset_name:
                    return dataset_item["dataset_id"]

    @classmethod
    def _get_version_id(cls, session, dataset_id, version_name):
        dataset = Dataset(session, dataset_id=dataset_id)
        version_list = dataset.get_version_list()
        version_id = None
        for version_item in version_list["versions"]:
            _version_name = version_item["version_name"]
            if _version_name == version_name:
                version_id = version_item["version_id"]
                break
        return version_id

    @classmethod
    def publish_dataset(cls, session, dataframe, dataset_name, version_name, obs_bucket, obs_path, description=""):
        """
        create dataset
        :param dataset_name:
        :param version_name:
        :param obs_bucket:
        :param obs_path:
        :param dataframe:
        :param description:
        :return:
        """

        if not obs_path.endswith("/"):
            obs_path = obs_path + "/"

        if obs_path.startswith("/"):
            obs_path = obs_path[1:]

        # save csv in local
        local_tmp_path = os.path.join(tempfile.gettempdir(), "temp_local_{}".format(str(round(time.time()))))
        os.mkdir(local_tmp_path)
        local_tmp_csv = os.path.join(local_tmp_path, "result.csv")
        dataframe.to_csv(local_tmp_csv, index=False)

        # create dataset
        dataset_type = constant.DATASET_TYPE_TABULAR
        managed = False
        work_path_type = 0
        work_path = "/{}/{}".format(obs_bucket, obs_path)
        schema = cls._generate_schema_for_dataset(dataframe)
        create_resp = cls.create_dataset(session=session,
                                         dataset_name=dataset_name,
                                         dataset_type=dataset_type,
                                         schema=schema,
                                         storage=ManagedStorage(managed, work_path, work_path_type),
                                         description=description)
        if "dataset_id" not in create_resp:
            raise Exception("Create dataset:{} error, resp is {}".format(dataset_name, json.dumps(create_resp)))
        dataset_id = create_resp['dataset_id']

        # import data to dataset
        dataset_instance = Dataset(session=session, dataset_id=dataset_id)

        dataset_instance.import_data(path=local_tmp_csv, format="csv", with_column_header=True,
                                     is_from_local=True)

        dataset_instance.release_dataset_version(version_name=version_name, version_format="csv")

    def __delete_dataset_by_id(self, dataset_id):
        """
        delete dataset by dataset instance with one authorize type.
        :return: response of deleting dataset
        """
        dataset_id = self.__check_dataset_id(dataset_id)
        return self.dataset_instance.delete_dataset(dataset_id)

    def update_dataset(self, dataset_name=None, description=None):
        """
        update structured dataset.
        :param dataset_name: dataset name
        :param description: dataset description
        :return: response of updating dataset
        """
        dataset_id = self.__check_dataset_id()
        update_dataset_body = dict()
        if dataset_name:
            update_dataset_body['dataset_name'] = dataset_name
        if description:
            update_dataset_body['description'] = description
        return self.dataset_instance.update_dataset(dataset_id, update_dataset_body)

    def get_dataset_info(self):
        """
        get dataset information
        :return: response of getting dataset information
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_dataset_info(dataset_id)

    def get_version_list(self):
        """
        get dataset version list
        :return: response of getting dataset version list
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_version_list(dataset_id)

    def release_dataset_version(self, version_name=None, version_format=None, description=None):
        """
        create dataset version
        :param version_name: version name
        :param version_format: create version format, supporting Default and CarbonData
        :param description: dataset version description
        :return: response of creating dataset version
        """
        dataset_id = self.__check_dataset_id()
        create_version_body = dict()
        if version_name:
            create_version_body['version_name'] = version_name
        if version_format:
            create_version_body['version_format'] = version_format
        if description:
            create_version_body['description'] = description
        return self.dataset_instance.release_dataset_version(dataset_id, create_version_body)

    def get_version_info(self, version_id):
        """
        get dataset version information
        :param version_id: version id
        :return: response of getting dataset version information
        """
        dataset_id = self.__check_dataset_id()
        if not version_id:
            raise ValueError("Version id is needed.")
        return self.dataset_instance.get_version_info(dataset_id, version_id)

    def create_reader(self, version_id, batch=1):
        """
        create reader to get specified version data of dataset
        """
        dataset_id = self.__check_dataset_id()

        if not version_id:
            raise ValueError("Version id is needed.")
        version_info = self.dataset_instance.get_version_info(dataset_id, version_id)
        data_path = version_info['data_path']
        version_format = version_info['version_format']
        with_column_header = version_info['with_column_header']
        schema = self.dataset_instance.get_schema(dataset_id)

        if version_format.upper() == constant.DATASET_VERSION_FORMAT_CSV.upper() or \
                version_format.upper() == constant.DATASET_VERSION_FORMAT_DEFAULT.upper():
            reader = CsvReader(self.session, data_path, batch, schema, with_column_header)
        else:
            raise Exception("Unsupported versoin format: {}, only support {}.".format(
                version_format, constant.DATASET_VERSION_FORMAT_CSV))
        return reader

    def list_samples(self, version_id=None, preview=None):
        """
        list sample preview, currently previewing 100 rows
        :param version_id: version id
        :return: structured dataset sample preview
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.list_samples(dataset_id, version_id, preview)

    def get_schema(self):
        """
        get dataset schema.
        :return: structured dataset schema
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_schema(dataset_id)

    def import_data(self, path, format=None, with_column_header=None, is_from_local=False):
        """
        import data to structured dataset.
        :param path: import data path, supporting OBS path and local path
        :param format: import file format, supporting csv and CarbonData
        :param with_column_header: valid for csv, indicating whether the first row is a column name,
                                with_column_header is True means skipping the first row
        :param is_from_local: import data from obs or local, is_from_local is True means importing from local path
        :return: response of importing data
        """
        dataset_id = self.__check_dataset_id()
        if not path:
            raise ValueError('The path is required.')
        if is_from_local:
            path = path.replace("\\", "/")
            desc_dataset_resp = self.dataset_instance.get_dataset_info(dataset_id=dataset_id)
            inner_work_path = desc_dataset_resp['inner_work_path']
            upload_temp_path = inner_work_path + constant.IMPORT_DATASET_TEMP_DIRECTORY_PREFIX + \
                               str(round(time.time() * 1000)) + "/"
            try:
                self.session.upload_data(upload_temp_path, path)
            except Exception:
                self.__delete_obs_directory(upload_temp_path)
                raise Exception("Failed to upload local path {} to OBS {}.".format(upload_temp_path, path))
            path = upload_temp_path
        import_data_body = dict()
        import_data_body['import_path'] = path
        if format:
            import_data_body['format'] = format
        if with_column_header:
            import_data_body['with_column_header'] = "true" if with_column_header else "false"
        import_data_response = self.dataset_instance.import_data(dataset_id, import_data_body)
        task_id = import_data_response['task_id']
        import_task_status = self.dataset_instance.get_import_task_info(dataset_id, task_id)['status']
        while import_task_status == "RUNNING" or import_task_status == "QUEUING":
            time.sleep(constant.IMPORT_DATASET_WAIT_INTERVAL_TIME)
            import_task_status = self.dataset_instance.get_import_task_info(dataset_id, task_id)['status']
        if is_from_local:
            self.__delete_obs_directory(path)
        return import_data_response

    def __delete_obs_directory(self, obs_path):
        """
        delete obs directory and its files
        :param obs_path: obs path
        """
        bucket_name = obs_path[1:obs_path.find("/", 1)]
        object_name = obs_path[obs_path.find("/", 1) + 1:]
        object_list = self.session.obs_client.list_all_objects(bucket_name, object_name)
        for objects in object_list:
            delete_objects_resp = self.session.obs_client.obs_client.deleteObject(bucket_name, objects)
            if delete_objects_resp.status > 300:
                raise Exception("Delete files existed in bucket failed, "
                                "error message is {}".format(delete_objects_resp.errorMessage))

    def get_import_task_info(self, task_id):
        """
        query import task
        :param task_id: import data task id
        :return: response of querying import task
        """
        dataset_id = self.__check_dataset_id()
        if not task_id:
            raise ValueError('The task_id is required.')
        return self.dataset_instance.get_import_task_info(dataset_id, task_id)

    def export_data(self, path, format=None, version_id=None, with_column_header=None):
        """
        export data to target path
        """
        dataset_id = self.__check_dataset_id()
        export_data_body = dict()
        if not path:
            raise ValueError('The path is required.')
        export_data_body['path'] = path
        if format:
            export_data_body['format'] = format
        if with_column_header:
            export_data_body['with_column_header'] = "true" if with_column_header else "false"
        if version_id:
            export_data_body['version_id'] = version_id
        return self.dataset_instance.export_data(dataset_id, export_data_body)

    def get_export_task_info(self, task_id):
        """
        query export task
        :param task_id: export data task id
        :return: response of querying export task
        """
        dataset_id = self.__check_dataset_id()
        if not task_id:
            raise ValueError('The task_id is required.')
        return self.dataset_instance.get_export_task_info(dataset_id, task_id)

    @staticmethod
    def _generate_schema_for_dataset(df):
        dtype_transform_dict = {
            "int64": "int",
            "float64": "float",
            "bool": "boolean",
            "object": "string"
        }
        schema = []
        index = 0
        for column in df.columns:
            dtype = df[column].dtypes
            dtype = dtype_transform_dict[str(dtype)]
            schema_item = {
                "schema_id": index,
                "name": column,
                "type": dtype
            }
            schema.append(schema_item)
            index += 1
        return schema
