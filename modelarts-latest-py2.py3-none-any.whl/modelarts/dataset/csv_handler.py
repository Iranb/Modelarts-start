import csv
import os
import shutil
import tempfile
import time

import pandas as pd
from modelarts import constant


class CsvReader(object):
    """
    File reader for CSV.
    """

    def __init__(self, session, data_path, batch, schema, with_column_header):
        """
        Create Csv Reader.
        :param session: Building interactions with HUAWEI Cloud service
        :param data_path: obs path
        :param batch: batch size of read rows
        :param schema: dataset schema
        :param with_column_header: whether the csv file is with column header
        """
        self.batch = batch
        self.with_column_header = with_column_header
        self.csvfile_list = list()
        self.csv_reader_list = list()
        self.csv_reader_current_idx = 0
        self.local_tmp_path = tempfile.gettempdir() + constant.LOCAL_TEMP_PATH + str(round(time.time())) + "/"
        self.local_tmp_csv_list = list()

        bucket_name = data_path[1:].split('/', 1)[0]
        object_name = data_path[1:].split('/', 1)[1]
        object_path_list = session.obs_client.list_all_objects(bucket_name, object_name)
        csv_path_list = self.__get_obs_csv_files(object_path_list)
        if not csv_path_list:
            raise Exception("The data directory of dataset version does not contain csv files, {}".format(data_path))

        for csv_path in csv_path_list:
            local_tmp_csv_path = self.__get_local_csv_file(bucket_name, csv_path, session.obs_client.obs_client,
                                                           self.local_tmp_path)
            self.local_tmp_csv_list.append(local_tmp_csv_path)
            csvfile = open(local_tmp_csv_path, 'r', encoding='utf-8')
            csv_reader = csv.reader(csvfile)
            if self.with_column_header:
                next(csv_reader)
            self.csvfile_list.append(csvfile)
            self.csv_reader_list.append(csv_reader)
        self.trans_func_list = self.__get_column_type_list(schema)
        self.field_names = [field['name'] for field in schema]

    @staticmethod
    def __get_obs_csv_files(object_path_list):
        csv_path_list = list()
        for object_path in object_path_list:
            if object_path.endswith(".csv"):
                csv_path_list.append(object_path)
        return csv_path_list

    @staticmethod
    def __get_local_csv_file(bucket_name, obs_csv_path, obs_client, local_tmp_path):
        """
        Download csv file to local temporary directory from OBS.
        :param bucket_name: obs bucket name
        :param obs_csv_path: obs file path
        :param obs_client: obs client
        :param local_tmp_path: local temporary directory
        :return: local temporary file path
        """
        resp = obs_client.getObject(bucket_name, obs_csv_path, loadStreamInMemory=True)
        if resp.body is None:
            raise Exception(
                "Failed to read obs file: {}, response is: {}.".format(bucket_name + '/' + obs_csv_path, resp))
        csv_b = resp.body.buffer
        if not os.path.exists(local_tmp_path):
            os.mkdir(local_tmp_path)
        local_tmp_csv_path = local_tmp_path + obs_csv_path[obs_csv_path.rfind('/') + 1:]
        with open(local_tmp_csv_path, "w", encoding='utf-8') as f:
            f.write(csv_b.decode())
        return local_tmp_csv_path

    @staticmethod
    def __get_column_type_list(schema):
        """
        get schema type list and generate type conversion function list.
        :param schema: dataset schema
        :return: value type conversion function list
        """
        return [constant.DATASET_COLUMN_TYPE_DICT[field['type']]
                if field['type'] in constant.DATASET_COLUMN_TYPE_DICT
                else str
                for field in schema]

    def __trans_value_type(self, row):
        """
        Trans value type of each row.
        :param row: each row in csv
        :return: new row
        """
        trans_type_row = list()
        for i, item in enumerate(row):
            try:
                new_value = self.trans_func_list[i](item)
            except ValueError:
                new_value = None
            trans_type_row.append(new_value)
        return trans_type_row

    def read_full_data(self):
        """
        Read full data by pandas.
        :return: dataframe
        """
        df_list = list()
        header = 0 if self.with_column_header else None
        for csv_file in self.local_tmp_csv_list:
            df_list.append(pd.read_csv(csv_file, header=header, names=self.field_names))
        return pd.concat(df_list)

    def read_next_row(self):
        """
        Read line by line.
        :return: one row, which type is List<value>
        """
        next_row = list()
        if self.csv_reader_current_idx >= len(self.csv_reader_list):
            return next_row
        for reader_idx in range(self.csv_reader_current_idx, len(self.csv_reader_list)):
            csv_reader = self.csv_reader_list[reader_idx]
            for row in csv_reader:
                next_row = self.__trans_value_type(row)
                return next_row
            self.csv_reader_current_idx += 1
        return next_row

    def read_next_batch_row(self):
        """
        Batch read.
        :return: batch rows, which type is List<List<value>>
        """
        next_rows = list()
        batch_size = self.batch
        if self.csv_reader_current_idx >= len(self.csv_reader_list):
            return next_rows

        for reader_idx in range(self.csv_reader_current_idx, len(self.csv_reader_list)):
            csv_reader = self.csv_reader_list[reader_idx]
            for row in csv_reader:
                next_rows.append(self.__trans_value_type(row))
                if len(next_rows) == batch_size:
                    return next_rows
            self.csv_reader_current_idx += 1
        return next_rows

    def has_next(self):
        """
        Whether the reader has next row, equivalent to whether there is next csv_reader.
        """
        return self.csv_reader_current_idx < len(self.csv_reader_list)

    def close(self):
        """
        Close reader after reading data, and delete local temporary directory.
        """
        for csvfile in self.csvfile_list:
            csvfile.close()
        if os.path.exists(self.local_tmp_path):
            shutil.rmtree(self.local_tmp_path)
