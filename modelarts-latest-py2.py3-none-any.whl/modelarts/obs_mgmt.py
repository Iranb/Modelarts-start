"""
Description: Huawei Cloud OBS and ROMA OBS management using roma s3 API
and obs client
Author: ModelArts SDK Team
Date: 2019/12/09 - 2019/12/13
"""

import base64
import json
import operator
import os
from abc import ABCMeta, abstractmethod
from multiprocessing import Pool
import sys

if sys.version_info.major < 3:
    from urllib import quote, unquote
else:
    from urllib.parse import quote, unquote

import requests
from six import with_metaclass

from obs import ObsClient
from modelarts import constant
from .util.obs_logger import OBSLogger


class OBSManagement(object):
    """
        OBS Management, operate OBS object, upload and download  data
    """

    def __init__(self, server=None, ak=None, sk=None, security_token=None,
                 app_id=None, app_token=None,
                 region_name=None):
        """
        OBS Management initial, include hwc obs and roma obs
        :param server: OBS server
        :param ak: access_key_id
        :param sk: secret_access_key
        :param security_token: security token for temporary ak:sk
        :param app_id: roma app_id
        :param app_token: roma csb token
        :param region_name: OBS region name
        """

        if all([server, ak, sk, app_id, app_token, region_name]):
            error_reason = "Can not initialize obs client, " \
                           "for redundant authentication information," \
                           "please choose server/ak/sk/region_name or " \
                           "app_id/app_token/region_name"
            OBSApiBase.handle_exception_logs(error_reason)

        elif all([server, ak, sk]):
            self.obs_client = HwcOBSApiImpl(server, ak, sk, security_token)

        elif all([app_id, app_token, region_name]):
            self.obs_client = RomaOBSApiImpl(app_id, app_token, region_name)

        else:
            error_reason = "Can not initialize obs client, " \
                           "for redundant authentication information"
            OBSApiBase.handle_exception_logs(error_reason)

    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        """
        return self.obs_client.is_obs_file(obs_file)

    def upload_file(self, src_local_file, dst_obs_dir):
        """ upload src_local_file to dst_obs_dir
        :param src_local_file: source local file path
        :param dst_obs_dir: destination obs directory
        :return:
        """
        self.obs_client.upload_file(src_local_file, dst_obs_dir)

    def upload_dir(self, src_local_dir, dst_obs_dir):
        """ upload src_local_dir to dst_obs_dir
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :return:
        """
        self.obs_client.upload_dir(src_local_dir, dst_obs_dir)

    def download_file(self, src_obs_file, dst_local_dir):
        """ download src_obs_file to dst_local_dir
        :param src_obs_file: source obs file path
        :param dst_local_dir: destination local directory
        :return:
        """
        self.obs_client.download_file(src_obs_file, dst_local_dir)

    @abstractmethod
    def download_dir(self, src_obs_dir, dst_local_dir):
        """ download src_obs_dir to dst_local_dir
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :return:
        """
        self.obs_client.download_dir(src_obs_dir, dst_local_dir)


class OBSApiBase(with_metaclass(ABCMeta, object)):
    """ OBS API Base
    """

    def __init__(self, ):
        pass

    @abstractmethod
    def upload_file(self, src_local_file, dst_obs_dir):
        """ upload local file to obs
        """
        pass

    @abstractmethod
    def upload_dir(self, src_local_dir, dst_obs_dir):
        """ upload local directory to obs
        """
        pass

    @abstractmethod
    def download_file(self, src_obs_dir, dst_local_dir):
        """ download obs file to local
        """
        pass

    @abstractmethod
    def download_dir(self, src_obs_dir, dst_local_dir):
        """ download obs directory to local
        """
        pass

    @abstractmethod
    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        """
        pass

    @classmethod
    def is_obs_head_format(cls, obs_path):
        """ whether the obs path head is correct format
        :param obs_path: format example: obs://bucket_name/dir/file.py
                          illegal format: obs://bucket_name, obs:///
        :return: true or false
        """
        # identify obs_path head is "obs://"
        current_obs_head_content = obs_path[
            slice(len(constant.OBS_HEAD_FORMAT))]
        is_head_legal = operator.eq(current_obs_head_content,
                                    constant.OBS_HEAD_FORMAT)
        if not is_head_legal:
            error_reason = "Illegal obs head format {}, correct " \
                           "format is {}".format(
                obs_path, constant.OBS_HEAD_FORMAT)
            cls.handle_exception_logs(error_reason)

        return is_head_legal

    @classmethod
    def is_legal_obs_dir_head_tail(cls, obs_dir):
        """
        :param obs_dir: obs directory
        :return:
        """
        is_legal_head_format = cls.is_obs_head_format(obs_dir)
        is_legal_tail_format = obs_dir.replace("\\", '/').endswith('/')

        if not is_legal_head_format or not is_legal_tail_format:
            error_reason = "Illegal obs dir format {}, " \
                           "correct format is {}".format(
                obs_dir, constant.OBS_DIR_FORMAT)
            cls.handle_exception_logs(error_reason)

        return is_legal_head_format and is_legal_tail_format

    @classmethod
    def is_legal_obs_file_head_tail(cls, obs_file):
        """
        :param obs_file: obs file
        :return:
        """
        is_legal_head_format = cls.is_obs_head_format(obs_file)
        is_legal_tail_format = not obs_file.replace("\\", '/').endswith('/')

        if not is_legal_head_format or not is_legal_tail_format:
            error_reason = "Illegal obs dir format {}, " \
                           "correct format is {}".format(
                obs_file, constant.OBS_FILE_FORMAT)
            cls.handle_exception_logs(error_reason)

        return is_legal_head_format and is_legal_tail_format

    @classmethod
    def extract_obs_dir_and_filename(cls, obs_path):
        """ extract last fir path form string obs_path
        :param obs_path: format example:
        obs://bucket_name/dir1/dir2/file.py  obs://bucket_name/dir1/dir2/
        :return: dir_path, filename,
        format: {dir1/dir2, file.py} or {dir1/dir2, ''}
        """
        bucket_name = cls.extract_bucket_name(obs_path)
        bucket_dir_path = \
            obs_path.split("{}{}/".format(constant.OBS_HEAD_FORMAT, bucket_name),
                           1)[-1]

        dir_path, file_name = os.path.split(bucket_dir_path)
        return dir_path, file_name

    @classmethod
    def extract_bucket_name(cls, obs_path):
        """ extract bucket name form string obs_path
        :param obs_path:  obs_path,
        format example: obs://bucket_name/dir/file.py or obs://bucket_name/dir/
        :return: bucket_name
        """
        cls.is_obs_head_format(obs_path)
        bucket_name = obs_path[len(constant.OBS_HEAD_FORMAT):].split('/', 1)[0]

        # check bucket name legality, ""
        if bucket_name.strip() == '':
            error_reason = "Illegal bucket path format {},correct format " \
                           "is obs://bucket_name/file.txt".format(obs_path)
            cls.handle_exception_logs(error_reason)

        return bucket_name

    @classmethod
    def get_local_dir_file_path_list(cls, local_dir_path):
        """
        :param local_dir_path: local directory path
        :return: file_path list, integral path
        """
        local_file_path_list = []
        for (dir_path, dir_names, file_names) in os.walk(local_dir_path):
            for filename in file_names:
                local_file_path_list.append(
                    os.path.join(dir_path, filename).replace("\\", "/"))

        return local_file_path_list

    @classmethod
    def extract_integral_dst_obs_dir(cls, src_local_file, src_local_dir,
                                     dst_obs_far_dir):
        """
        :param src_local_file:  integral local file path,
        e.g. c://dir1/dir2/dir3/dir4/file.py, included by src_local_dir
        :param src_local_dir:  e.g c://dir1/dir2
        :param dst_obs_far_dir:  obs://bucket_name/obs_dir1/obs_dir2
        :return: illegal destination obs directory path
        obs://bucket_name/obs_dir1/obs_dir2/dir3/dir4/
        """
        src_local_file = src_local_file.replace("\\", "/")
        src_local_dir = src_local_dir.replace("\\", "/")
        dst_obs_far_dir = dst_obs_far_dir.replace("\\", "/")

        # e.g C:/dir1/dir2/dir3/test.py -> dir3/test.py
        local_dir_prefix = src_local_file.split(src_local_dir, 1)[-1]

        # e.g obs://bucket_name/dir_name/ -> obs://bucket_name/dir_name/dir3/test.py
        dst_obs_file = os.path.join(dst_obs_far_dir, local_dir_prefix)

        # e.g obs://bucket_name/dir_name/dir3/test.py -> obs://bucket_name/dir_name/dir3
        file_path, file_name = os.path.split(dst_obs_file)

        # e.g obs://bucket_name/dir_name/dir3 -> obs://bucket_name/dir_name/dir3/
        dst_obs_dir = os.path.join(file_path, '').replace("\\", "/")

        return dst_obs_dir

    @classmethod
    def _make_local_dir_exist(cls, local_dir):
        """ make sure local dir exists
        :param local_dir: local dir integral path, .e.g. c://dir1/dir2
        :return:
        """
        if local_dir and not os.path.exists(local_dir):
            os.makedirs(local_dir)

    @classmethod
    def is_local_file(cls, local_file):
        """
        :param local_file: local file path
        :return: True or False
        """
        if not os.path.isfile(local_file):
            error_reason = "The local file {} is not exist".format(local_file)
            cls.handle_exception_logs(error_reason)

        return os.path.isfile(local_file)

    @classmethod
    def is_local_dir(cls, local_dir):
        """
        :param local_dir: local directory path
        :return: True or False
        """
        if not os.path.isdir(local_dir):
            error_reason = "The local dir {} is not exist".format(local_dir)
            cls.handle_exception_logs(error_reason)

        return os.path.isdir(local_dir)

    @classmethod
    def handle_exception_logs(cls, error_reason):
        """
        :param error_reason: error reason
        :return:
        """
        OBSLogger.common_error_log(error_content=error_reason)
        raise Exception(error_reason)

    @classmethod
    def quote_obs_dir(cls, obs_dir):
        obs_dir_path = quote(obs_dir[len(constant.OBS_HEAD_FORMAT):])
        return constant.OBS_HEAD_FORMAT + obs_dir_path

    @classmethod
    def get_integral_dst_obs_dir(cls, src_local_file, src_local_dir, dst_obs_far_dir_path):
        src_local_file_split = src_local_file.split(src_local_dir, 1)[-1].rsplit('/', 1)
        if len(src_local_file_split) > 1:
            src_local_file_left = quote(src_local_file_split[0])
            src_local_file_fix = src_local_dir + src_local_file_left + '/' + src_local_file_split[1]
            integral_dst_obs_dir = OBSApiBase.extract_integral_dst_obs_dir(
                src_local_file_fix, src_local_dir,
                dst_obs_far_dir_path)
        else:
            integral_dst_obs_dir = OBSApiBase.extract_integral_dst_obs_dir(
                src_local_file, src_local_dir,
                dst_obs_far_dir_path)
        return integral_dst_obs_dir


class RomaOBSApiImpl(OBSApiBase):
    """  Operate ROMA OBS object.
    """

    def __init__(self, app_id, csb_token, region_name):
        OBSApiBase.__init__(self)

        self.app_id = app_id
        self.csb_token = csb_token
        self.region_name = region_name
        self.roma_obs_host = constant.ROMA_OBS_HOST
        self.headers = {"Content-Type": "application/json",
                        "csb-token": self.csb_token}

    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        :param obs_file:
        :return: whether obs file
        """
        OBSApiBase.is_legal_obs_file_head_tail(obs_file)

        bucket_name = OBSApiBase.extract_bucket_name(obs_file)
        bucket_dir_path, bucket_file_name = OBSApiBase. \
            extract_obs_dir_and_filename(obs_file)
        dir_object_list = self._get_bucket_dir_objects(bucket_name,
                                                       bucket_dir_path)

        bucket_file_path_without_bucket_name = \
            os.path.join(bucket_dir_path, bucket_file_name).replace("\\", '/')

        return bucket_file_path_without_bucket_name in dir_object_list

    def upload_file(self, src_local_file, dst_obs_dir):
        """ upload src_local_file to dst_obs_dir
        :param src_local_file: source local file path,
        e.g. c://programs/obs.py"
        :param dst_obs_dir: destination obs directory
        e.g. obs://bucket_name/obs_dir/"
        :return:
        """
        OBSApiBase.is_legal_obs_dir_head_tail(dst_obs_dir)
        OBSApiBase.is_local_file(src_local_file)

        bucket_name = OBSApiBase.extract_bucket_name(dst_obs_dir)
        bucket_file_address = self._get_bucket_file_address(bucket_name)

        file_path, file_name = os.path.split(src_local_file)
        file_name_quote = quote(file_name)
        dst_obs_dir_quote = OBSApiBase.quote_obs_dir(dst_obs_dir)
        bucket_dir_path, bucket_file_name = \
            OBSApiBase.extract_obs_dir_and_filename(dst_obs_dir_quote)

        bucket_file_path_without_bucket_name = os.path.join(bucket_dir_path,
                                                            file_name_quote)
        bucket_file_path_without_bucket_name_b64 = base64.b64encode(
            bucket_file_path_without_bucket_name.encode()).decode('utf-8')

        self._roma_api_upload_file(bucket_name,
                                   bucket_file_path_without_bucket_name_b64,
                                   bucket_file_address,
                                   src_local_file)

        dst_obs_dir_unquote = unquote(dst_obs_dir_quote)
        OBSLogger.common_info_log("Successfully upload local {} to roma {}".
                                  format(src_local_file, dst_obs_dir_unquote))

    def upload_dir(self, src_local_dir, dst_obs_dir):
        """ upload src_local_dir to dst_obs_dir
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :return:
        """
        OBSApiBase.is_legal_obs_dir_head_tail(dst_obs_dir)
        OBSApiBase.is_local_dir(src_local_dir)

        src_local_file_list = OBSApiBase.get_local_dir_file_path_list(
            src_local_dir)
        local_dir_name = os.path.basename(os.path.normpath(src_local_dir))

        dst_obs_far_dir_path = os.path.join(dst_obs_dir, local_dir_name,
                                            '').replace("\\", '/')

        threads = max(min(constant.DEFAULT_THREADS, len(src_local_file_list)), 1)
        pool = Pool(threads)

        for src_local_file in src_local_file_list:
            integral_dst_obs_dir = OBSApiBase.extract_integral_dst_obs_dir(
                src_local_file, src_local_dir, dst_obs_far_dir_path)
            pool.apply_async(self.upload_file,
                             args=(src_local_file, integral_dst_obs_dir,))
            # self.upload_file(src_local_file, integral_dst_obs_dir)

        pool.close()
        pool.join()

        OBSLogger.common_info_log(
            "Successfully upload local {} to roma {}".format(src_local_dir,
                                                             dst_obs_dir))

    def download_file(self, src_obs_file, dst_local_dir, bucket_name=None,
                      bucket_file_address=None):
        """ download src_obs_file to dst_local_dir
        :param src_obs_file: source obs file path
        :param dst_local_dir: destination local directory
        :param bucket_name:  optional, for download directory,
        avoid repeat use roma api
        :param bucket_file_address: optional, for download directory,
        avoid repeat use roma api
        :return:
        """
        OBSApiBase.is_legal_obs_file_head_tail(src_obs_file)
        OBSApiBase._make_local_dir_exist(dst_local_dir)

        bucket_name = OBSApiBase.extract_bucket_name(
            src_obs_file) if not bucket_name else bucket_name

        bucket_file_address = self._get_bucket_file_address(
            bucket_name) if not bucket_file_address else bucket_file_address

        src_obs_file_quote = OBSApiBase.quote_obs_dir(src_obs_file)
        bucket_dir_path, bucket_file_name = \
            OBSApiBase.extract_obs_dir_and_filename(src_obs_file_quote)

        bucket_file_path_without_bucket_name = \
            os.path.join(bucket_dir_path, bucket_file_name).replace("\\", '/')

        bucket_file_path_without_bucket_name_b64 = base64.b64encode(
            bucket_file_path_without_bucket_name.encode()).decode('utf-8')

        if not os.path.exists(dst_local_dir):
            os.makedirs(dst_local_dir)
        dst_local_file_path = os.path.join(dst_local_dir, bucket_file_name)

        self._roma_api_download_file(
            bucket_file_service_address=bucket_file_address,
            bucket_name=bucket_name,
            bucket_file_path_b64=bucket_file_path_without_bucket_name_b64,
            dst_local_file_path=dst_local_file_path
        )

        OBSLogger.common_info_log("Successfully download roma {} to local {}".
                                  format(src_obs_file, dst_local_dir))

    def download_dir(self, src_obs_dir, dst_local_dir):
        """ download src_obs_dir to dst_local_dir
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :return:
        """
        # check parameters legality
        OBSApiBase.is_legal_obs_dir_head_tail(src_obs_dir)
        OBSApiBase._make_local_dir_exist(dst_local_dir)

        # get dir object list
        src_obs_dir_quote = OBSApiBase.quote_obs_dir(src_obs_dir)
        bucket_name = OBSApiBase.extract_bucket_name(src_obs_dir_quote)
        bucket_file_address = self._get_bucket_file_address(bucket_name)
        bucket_dir_path, bucket_file_name = \
            OBSApiBase.extract_obs_dir_and_filename(src_obs_dir_quote)

        bucket_dir_object_list = \
            self._get_bucket_dir_objects(bucket_name, bucket_dir_path)

        bucket_dir_object_list = \
            ["{}{}/{}".format(constant.OBS_HEAD_FORMAT, bucket_name, i) for i in
             bucket_dir_object_list]

        # get src dir_name. s3://bucket_name/ , dst_dir_name=''
        dst_dir_name = bucket_dir_path if bucket_dir_path == '' else \
            os.path.split(os.path.normpath(src_obs_dir_quote))[1]

        dst_local_dir = \
            os.path.join(dst_local_dir, dst_dir_name, '').replace("\\", '/')

        threads = max(
            min(constant.DEFAULT_THREADS, len(bucket_dir_object_list)), 1)
        pool = Pool(threads)

        is_file_downloaded = False
        for obs_src_file in bucket_dir_object_list:
            if src_obs_dir_quote in obs_src_file:
                prefix_dir, prefix_file = os.path.split(
                    obs_src_file.split(src_obs_dir_quote, 1)[-1])

                new_dst_local_dir = os.path.join(dst_local_dir, prefix_dir,
                                                 '').replace("\\", '/')

                pool.apply_async(self.download_file,
                                 args=(
                                     obs_src_file, new_dst_local_dir, bucket_name,
                                     bucket_file_address,))
                # self.download_file(obs_src_file, new_dst_local_dir, bucket_name, bucket_file_address)
                is_file_downloaded = True

        pool.close()
        pool.join()
        if is_file_downloaded:
            OBSLogger.common_info_log("Successfully download roma {} to "
                                      "local {}".
                                      format(src_obs_dir, dst_local_dir))
        else:
            OBSLogger.common_info_log(
                "No object in roma {}, please check it.".format(src_obs_dir))

    def _get_bucket_file_address(self, bucket_name):
        """ get bucket file operation endpoint
        :param bucket_name:
        :return: roma bucket file endpoint
        """
        bucket_id = self._get_bucket_id_by_name(bucket_name=bucket_name)
        bucket_file_service_address = self._roma_api_get_file_upload_endpoint(
            bucket_id)

        return bucket_file_service_address

    def _get_bucket_dir_objects(self, bucket_name, bucket_dir_path):
        """ get all object in obs directory
        :param bucket_dir_path: obs directory, as s3://
        :param bucket_name:
        :return: object_keys_list in bucket_dir_path
        """
        bucket_file_service_address = self._get_bucket_file_address(
            bucket_name)

        bucket_dir_path_b64 = base64.b64encode(
            bucket_dir_path.encode()).decode('utf-8')
        object_keys_list = self._get_bucket_whole_object_keys(
            bucket_file_service_address,
            bucket_name,
            bucket_dir_path_b64)

        return object_keys_list

    def _get_bucket_id_by_name(self, bucket_name):
        """
        :param bucket_name: bucket name
        :return: bucket id
        """
        bucket_list = self._roma_api_get_bucket_list()
        bucket_name_list = [i['name'] for i in bucket_list]

        if bucket_name not in bucket_name_list:
            error_reason = "The bucket {} not exist in current account.".format(
                bucket_name)
            OBSApiBase.handle_exception_logs(error_reason)

        bucket_id = bucket_list[bucket_name_list.index(bucket_name)]['id']
        return bucket_id

    def _get_bucket_whole_object_keys(self, bucket_file_service_address,
                                      bucket_name, bucket_dir_path_b64,
                                      nextmarker=""):
        """
        :param bucket_file_service_address: bucket file service address
        :param bucket_name:  bucket id is bucket name
        :param bucket_dir_path_b64:  bucket directory base64 coded
        :param nextmarker: next page flags
        :return:  objectKeys: all object keys path of current directory
        """
        is_truncated = True
        object_keys = []
        while is_truncated:
            resp = self._roma_api_get_bucket_object_keys(
                bucket_file_service_address, bucket_name, bucket_dir_path_b64,
                nextmarker)
            nextmarker = resp['nextmarker']
            is_truncated = resp['truncated'] == str(True).lower()
            object_keys.extend(resp['objectKeys'])

        whole_object_path = [i['objectKey'] for i in object_keys]
        return whole_object_path

    def _roma_api_upload_file(self, bucket_name,
                              bucket_file_path_without_bucket_name_b64,
                              bucket_file_address,
                              src_local_file):
        """
        :param bucket_name:
        :param bucket_file_path_without_bucket_name_b64:
        :param bucket_file_address:
        :param src_local_file:
        :return:
        """
        request_url = "{}/rest/boto3/s3/HEC/{}/{}/{}/{}".format(
            bucket_file_address,
            self.region_name,
            self.csb_token,
            bucket_name,
            bucket_file_path_without_bucket_name_b64)

        headers = {"Content-Type": "text/plain", "csb-token": self.csb_token}
        body = open(src_local_file, 'rb')
        try:
            response = requests.put(request_url, data=body, headers=headers,
                                    verify=False)
            if response.status_code > 200:
                OBSLogger.roma_error_log(api_response=response)
                raise Exception(response.content)

        except Exception as e:
            error_reason = "Failed to upload file,  {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_download_file(self, bucket_file_service_address, bucket_name,
                                bucket_file_path_b64,
                                dst_local_file_path):
        """ roam api for download file
        :param bucket_file_service_address:
        :param bucket_name:
        :param bucket_file_path_b64:
        :param dst_local_file_path:
        :return:
        """
        request_url = '{}/rest/boto3/s3/HEC/{}/{}/{}/{}'.format(
            bucket_file_service_address,
            self.region_name,
            self.csb_token,
            bucket_name,
            bucket_file_path_b64,
        )

        headers = {"Content-Type": "text/plain", "csb-token": self.csb_token}
        try:
            response = requests.get(request_url, headers=headers, verify=False)

            if response.status_code > 200:
                OBSLogger.roma_error_log(api_response=response)
                raise Exception(response.content)

            with open(dst_local_file_path, 'wb') as f:
                f.write(response.content)
                f.close()

        except Exception as e:
            error_reason = "Failed to download file,  {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_get_bucket_object_keys(self, bucket_file_service_address,
                                         bucket_name, bucket_dir_path_b64,
                                         nextmarker):
        """
        :param bucket_file_service_address: bucket file service address
        :param bucket_name:  bucket id is bucket name
        :param bucket_dir_path_b64:  bucket directory base64 coded
        :return:  objectKeys
        """

        request_url = "{endpoint}/rest/boto3/s3/list/bucket/" \
                      "objectkeys?vendor=HEC&region" \
                      "={region}&bucketid={bucketid}&apptoken=" \
                      "{apptoken}&objectkey=" \
                      "{objectkey}&nextmarker={nextmarker}".format(
            endpoint=bucket_file_service_address,
            region=self.region_name,
            bucketid=bucket_name,
            apptoken=self.csb_token,
            objectkey=bucket_dir_path_b64,
            nextmarker=nextmarker)

        headers = {"Content-Type": "application/json",
                   "csb-token": self.csb_token}

        try:
            response = requests.get(request_url, headers=headers, verify=False)

            if response.status_code > 200:
                OBSLogger.roma_error_log(api_response=response)
                raise Exception(response.content)
            return json.loads(response.content)

        except Exception as e:
            error_reason = "Fail to get bucket object keys,  {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_get_bucket_list(self):
        """ get roma user bucket list
        :return: bucket list
        """
        request_url = "{host}s3/listbuckets?appid={app_id}".format(
            host=self.roma_obs_host, app_id=self.app_id)

        try:
            response = requests.get(request_url, headers=self.headers,
                                    verify=False)

            if json.loads(response.content)['success']:
                return json.loads(response.content)['buckets']

            OBSLogger.roma_error_log(api_response=response)
            raise Exception(json.loads(response.content)['msg'])

        except Exception as e:
            error_reason = "Failed to get bucket list {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_get_file_upload_endpoint(self, bucket_id):
        """
        :param bucket_id: roma bucket id
        :return: file server ip and port for upload file
        """
        try:
            request_url = "{}userconsole/get/hec/fileserver/ip/and/port?id={}". \
                format(self.roma_obs_host, bucket_id)
            response = requests.get(request_url, headers=self.headers,
                                    verify=False)

            if json.loads(response.content)['success']:
                file_service_address = json.loads(response.content)[
                    'fileServerIpAndPort']
                return file_service_address

            OBSLogger.roma_error_log(api_response=response)
            raise Exception(json.loads(response.content)['msg'])

        except Exception as e:
            error_reason = "Failed to get file server ip and port, for {}". \
                format(e)
            OBSApiBase.handle_exception_logs(error_reason)


class HwcOBSApiImpl(OBSApiBase):
    """  Operate ROMA OBS object.
    """

    def __init__(self, server, ak, sk, security_token=None, is_secure=True,
                 path_style=True, proxy_host=None,
                 proxy_port=None, proxy_username=None, proxy_password=None):
        OBSApiBase.__init__(self)

        self.access_key_id = ak
        self.secret_access_key = sk
        self.security_token = security_token
        self.is_secure = is_secure
        self.server = server
        self.path_style = path_style
        self.proxy_host = proxy_host
        self.proxy_port = proxy_port
        self.proxy_username = proxy_username
        self.proxy_password = proxy_password

    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        :param obs_file:
        :return: whether obs file
        """
        OBSApiBase.is_legal_obs_file_head_tail(obs_file)
        bucket_name = OBSApiBase.extract_bucket_name(obs_file)

        # bucket_file_path dir1/dir2/file.txt
        bucket_file_path = \
            obs_file.split("{}{}/".format(constant.OBS_HEAD_FORMAT, bucket_name),
                           1)[-1]
        object_meta_info = self._hwc_api_get_object_metadata(bucket_name,
                                                             bucket_file_path)

        return object_meta_info.status == 200

    def upload_file(self, src_local_file, dst_obs_dir):
        """ upload src_local_file to dst_obs_dir
        :param src_local_file: source local file path
        :param dst_obs_dir: destination obs directory
        :return:
        """
        OBSApiBase.is_legal_obs_dir_head_tail(dst_obs_dir)
        OBSApiBase.is_local_file(src_local_file)

        file_path, file_name = os.path.split(src_local_file)
        dst_obs_dir_quote = OBSApiBase.quote_obs_dir(dst_obs_dir)
        legal_dst_obs_dir = self._extract_obs_dir_format(dst_obs_dir_quote)

        self._hwc_api_put_file(legal_dst_obs_dir, file_name, src_local_file)
        dst_obs_dir_unquote = unquote(dst_obs_dir_quote)
        OBSLogger.common_info_log(
            "Successfully upload local {} to {}".format(src_local_file,
                                                        dst_obs_dir_unquote))

    def upload_dir(self, src_local_dir, dst_obs_dir):
        """ upload src_local_dir to dst_obs_dir
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :return:
        """
        OBSApiBase.is_legal_obs_dir_head_tail(dst_obs_dir)
        OBSApiBase.is_local_dir(src_local_dir)

        src_local_file_list = OBSApiBase.get_local_dir_file_path_list(
            src_local_dir)
        local_dir_name = os.path.basename(os.path.normpath(src_local_dir))

        dst_obs_far_dir_path = os.path.join(dst_obs_dir, local_dir_name,
                                            '').replace("\\", '/')

        threads = max(min(constant.DEFAULT_THREADS, len(src_local_file_list)),
                      1)
        pool = Pool(threads)

        for src_local_file in src_local_file_list:
            integral_dst_obs_dir = OBSApiBase.extract_integral_dst_obs_dir(
                src_local_file, src_local_dir, dst_obs_far_dir_path)
            pool.apply_async(self.upload_file,
                             args=(src_local_file, integral_dst_obs_dir,))
            # self.upload_file(src_local_file, integral_dst_obs_dir)

        pool.close()
        pool.join()

        OBSLogger.common_info_log(
            "Successfully upload local {} to {}".format(src_local_dir,
                                                        dst_obs_dir))

    def download_file(self, src_obs_file, dst_local_dir):
        """ download src_obs_file to dst_local_dir
        :param src_obs_file: source obs file path
        :param dst_local_dir: destination local directory
        :return:
        """
        OBSApiBase.is_legal_obs_file_head_tail(src_obs_file)
        OBSApiBase._make_local_dir_exist(dst_local_dir)

        bucket_name = OBSApiBase.extract_bucket_name(src_obs_file)

        bucket_dir_path, bucket_file_name = \
            OBSApiBase.extract_obs_dir_and_filename(src_obs_file)

        bucket_file_path_without_bucket_name = \
            os.path.join(bucket_dir_path, bucket_file_name).replace("\\", '/')

        if not os.path.exists(dst_local_dir):
            os.makedirs(dst_local_dir)
        dst_local_file_path = os.path.join(dst_local_dir, bucket_file_name)

        self._hwc_api_get_object(bucket_name,
                                 bucket_file_path_without_bucket_name,
                                 dst_local_file_path)

        OBSLogger.common_info_log(
            "Successfully download {} to local {}".format(src_obs_file,
                                                          dst_local_dir))

    def download_dir(self, src_obs_dir, dst_local_dir):
        """ download src_obs_dir to dst_local_dir
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :return:
        """
        # check parameters legality
        OBSApiBase.is_legal_obs_dir_head_tail(src_obs_dir)
        OBSApiBase._make_local_dir_exist(dst_local_dir)

        # get obs dir object list
        bucket_name = OBSApiBase.extract_bucket_name(src_obs_dir)
        bucket_dir_path, bucket_file_name = \
            OBSApiBase.extract_obs_dir_and_filename(src_obs_dir)
        bucket_dir_path = os.path.join(bucket_dir_path, '')

        bucket_dir_object_list = self._get_bucket_dir_objects(bucket_name,
                                                              bucket_dir_path)

        # list element obs://bucket_name/dir1/file.txt
        bucket_dir_object_list = [
            "{}{}/{}".format(constant.OBS_HEAD_FORMAT, bucket_name, i) for i in
            bucket_dir_object_list]

        dst_dir_name = bucket_dir_path if bucket_dir_path == '' else \
            os.path.split(os.path.normpath(src_obs_dir))[1]
        dst_local_dir = \
            os.path.join(dst_local_dir, dst_dir_name, '').replace("\\", '/')

        threads = max(
            min(constant.DEFAULT_THREADS, len(bucket_dir_object_list)), 1)
        pool = Pool(threads)

        is_file_downloaded = False
        for obs_src_file in bucket_dir_object_list:
            if src_obs_dir in obs_src_file:
                prefix_dir, prefix_file = os.path.split(
                    obs_src_file.split(src_obs_dir, 1)[-1])

                new_dst_local_dir = os.path.join(dst_local_dir, prefix_dir,
                                                 '').replace("\\", '/')

                pool.apply_async(self.download_file,
                                 args=(obs_src_file, new_dst_local_dir,))

                # self.download_file(obs_src_file, new_dst_local_dir)
                is_file_downloaded = True

        pool.close()
        pool.join()

        if is_file_downloaded:
            OBSLogger.common_info_log(
                "Successfully download {} to local {}".format(src_obs_dir,
                                                              dst_local_dir))
        else:
            OBSLogger.common_info_log("No object in obs {}, please check it.".format(src_obs_dir))

    def _get_obs_client(self):
        """ initial obs client
        :return: obs client
        """
        obs_client = ObsClient(access_key_id=self.access_key_id,
                               secret_access_key=self.secret_access_key,
                               security_token=self.security_token,
                               is_secure=self.is_secure,
                               server=self.server,
                               path_style=self.path_style,
                               proxy_host=self.proxy_host,
                               proxy_port=self.proxy_port,
                               proxy_username=self.proxy_username,
                               proxy_password=self.proxy_password)
        return obs_client

    def _get_bucket_dir_objects(self, bucket_name, prefix):
        """ get bucket_dir all objects list, all objects integral path
        :param bucket_name:
        :param prefix: bucket_dir_path  .e.g. dir1/dir2/
        :return: object_list  object list without bucket name,
        .e.g ['dir1/dir2/bucket.py', 'dir1/dir2/obs.py']
        """
        all_object_info_list = []
        object_list = []
        marker = None

        # get all all_object_info_list,
        # e.g. [ [marker1_object_resp], [marker2_object_resp]]
        while True:
            list_objects_resp = self._hwc_api_list_objects(bucket_name, prefix,
                                                           100, marker)
            all_object_info_list.append(list_objects_resp)

            if not list_objects_resp.body.is_truncated:
                break
            marker = list_objects_resp.body.next_marker

        # get object_list, e.g. ['dir1/dir2/bucket.py', 'dir1/dir2/obs.py']
        for object_info_list in all_object_info_list:
            for content in object_info_list.body.contents:
                if content.key.endswith('/'):
                    continue
                object_list.append(content.key)

        return object_list

    @classmethod
    def _extract_obs_dir_format(cls, pre_obs_dir):
        """  extract obs dir as hwc obs format bucket_name/dir1
        :param pre_obs_dir: obs://bucket_name/dir1/ -> bucket_name/dir1
        :return: bucket_name/dir1
        """
        obs_dir_del_head = pre_obs_dir.split(constant.OBS_HEAD_FORMAT, 1)[-1]
        legal_obs_dir = os.path.normpath(obs_dir_del_head)
        legal_obs_dir = legal_obs_dir.replace("\\", "/")

        return legal_obs_dir

    def _hwc_api_get_object_metadata(self, bucket_name, file_path):
        """
        :param bucket_name: bucket name
        :param file_path: file_path, .e.g.dir1/dir2/obs.py
        :return:
        """
        try:
            obs_client = self._get_obs_client()
            resp = obs_client.getObjectMetadata(bucket_name, file_path)
            if resp.status > 300 and resp.status != 404:
                OBSLogger.hwc_error_log(api_response=resp)
                raise Exception("errorMessage: {}".format(resp.errorMessage))
            return resp

        except Exception as e:
            error_reason = "Failed to get object metadata, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _hwc_api_list_objects(self, bucket_name, prefix, max_keys, marker):
        """ hwc obs client list objects
        :param bucket_name:
        :param prefix:
        :param max_keys:
        :param marker:
        :return:
        """
        try:
            obs_client = self._get_obs_client()
            list_objects_resp = obs_client.listObjects(bucketName=bucket_name,
                                                       prefix=prefix,
                                                       max_keys=max_keys,
                                                       marker=marker)
            if list_objects_resp.status > 300:
                OBSLogger.hwc_error_log(api_response=list_objects_resp)
                raise Exception(
                    "errorMessage: {}".format(list_objects_resp.errorMessage))
            return list_objects_resp

        except Exception as e:
            error_reason = "Failed to list objects, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _hwc_api_get_object(self, bucket_name,
                            bucket_file_path_without_bucket_name,
                            dst_local_file_path):
        """ hwc obs client get object
        :param bucket_name: bucket name
        :param bucket_file_path_without_bucket_name:
        bucket file path without bucket name
        :param dst_local_file_path: local destination file path, include file name
        :return:
        """
        try:
            obs_client = self._get_obs_client()
            resp = obs_client.getObject(bucket_name,
                                        bucket_file_path_without_bucket_name,
                                        downloadPath=dst_local_file_path)
            if resp.status > 300:
                OBSLogger.hwc_error_log(api_response=resp)
                raise Exception("errorMessage: {}".format(resp.errorMessage))

        except Exception as e:
            error_reason = "Failed to download object, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _hwc_api_put_file(self, legal_dst_obs_dir, file_name, src_local_file):
        """ HWC OBS client for  putFile
        :param legal_dst_obs_dir:  bucket_name/dir1/dir2
        :param file_name: file.py , after upload to obs file_name
        :param src_local_file:
        :return:
        """
        try:
            obs_client = self._get_obs_client()
            resp = obs_client.putFile(legal_dst_obs_dir, file_name,
                                      src_local_file)
            if resp.status > 300:
                OBSLogger.hwc_error_log(api_response=resp)
                raise Exception("errorMessage: {}".format(resp.errorMessage))

        except Exception as e:
            error_reason = "Failed to upload file, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)
