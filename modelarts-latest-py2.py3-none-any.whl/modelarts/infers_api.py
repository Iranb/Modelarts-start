"""
Inference API for ModelArts online inference service
"""
from __future__ import absolute_import
from modelarts.client.api_client import ApiClient
import six
import json


class InfersApi(object):

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def service_model_reasoning(self, data, data_type, **kwargs):
        """
        :param data: reasoning data(file path or json data)
        :param data_type: reasoning data type, support json/not json
        if data_type.upper() is JSON means that reasoning request 'body' is JSON data
            and 'Content-Type' is 'application/json'
            and data should provide json data or json file path
        if data_type.upper() is not JSON means that reasoning request
            'Content-Type' is 'multipart/form-data'
            and data should provide file path
        :param kwargs: if data_type.upper() is not JSON,
            it should contain 'file_key' or use data_type as file_key
        :return: reasoning result
        """
        kwargs['_return_http_data_only'] = True
        all_params = ['_return_http_data_only', '_preload_content',
                      '_request_timeout', 'file_key']
        # Get all variables in the method
        params = locals()
        # Traverse key-value pairs to see if they are in all_params
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError("Got an unexpected keyword argument '%s' "
                                "to method service_model_reasoning" % key)
            params[key] = val
        del params['kwargs']

        self.params_verify(params)
        return self.send_reasoning_request(data, data_type, params)

    @staticmethod
    def params_verify(params):
        # verify the required parameter type is set
        if 'data' not in params or params['data'] is None:
            raise ValueError("Missing the required parameter 'data' when "
                             "calling `service_model_reasoning_files`")

        if 'data_type' not in params or params['data_type'] is None:
            raise ValueError("Missing the required parameter 'data_type' when "
                             "calling `service_model_reasoning_files`")

    def send_reasoning_request(self, data, data_type, params):
        """
        :param data: reasoning data
        :param data_type: reasoning data type
        :param params: request parameters
        :return: reasoning result
        """

        # Assignment to the corresponding parameter
        collection_formats = {}
        path_params = {}
        query_params = []
        form_params = []
        local_var_files = {}
        body_params = None

        if 'JSON' == data_type.upper():
            header_params, body_params = self.build_json_reasoning_data(data)
        else:
            header_params, local_var_files = self.build_image_reasoning_data(
                data, params)

        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])

        # Authentication setting
        auth_settings = ['ApiTokenAuth']

        return self.api_client.call_api(
            '/', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='InfersResponse',
            auth_settings=auth_settings,
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def build_json_reasoning_data(self, data):
        header_params = {}
        if type(data) == str:
            try:
                body_params = json.loads(data)
            except BaseException:
                json_file = open(data)
                body_params = json.load(json_file, encoding='utf-8')
                json_file.close()
        else:
            body_params = data
        header_params[
            'Content-Type'] = self.api_client.select_header_content_type(
            ['application/json'])
        print('Content is json message body: %s.' % body_params)
        return header_params, body_params

    def build_image_reasoning_data(self, data, params):
        header_params = {}
        local_var_files = {}

        header_params[
            'Content-Type'] = self.api_client.select_header_content_type(
            ['multipart/form-data'])
        if 'file_key' in params and params['file_key'] is not None:
            local_var_files[params['file_key']] = data
        else:
            local_var_files[params['data_type']] = data
        print("Content is not json message body. file: %s" % data)
        return header_params, local_var_files
