"""An estimator class for training of modelarts sdk."""
import logging
import time
from json import JSONEncoder

from . import constant
from .config.auth import auth_by_apig, auth_by_roma_estimatorv2_api
from .estimator_base import EstimatorBase, TrainingJobBase
from .util.config import Config
from .util.secret_util import auth_expired_handler

logging.getLogger().setLevel(logging.INFO)
JOB_STATE = constant.JOB_STATE
HTTPS_GET = constant.HTTPS_GET
HTTPS_POST = constant.HTTPS_POST
HTTPS_DELETE = constant.HTTPS_DELETE
HTTPS_PUT = constant.HTTPS_PUT


class Estimator(EstimatorBase):

    def __init__(self, modelarts_session, train_instance_count=None,
                 train_instance_type=None,
                 output_path=None, base_job_name=None, code_dir=None,
                 boot_file=None, hyperparameters=None,
                 framework_type=None, framework_version=None,
                 log_url=None, user_image_url=None,
                 user_command=None, job_description=None,
                 job_id=None,
                 job_type=None,
                 environment=None,
                 volumes=None,
                 policy="regular"):
        """
        Initialize a ModelArts Estimator Object.
        """
        super(Estimator, self).__init__(modelarts_session, train_instance_count, train_instance_type,
                                        output_path, base_job_name, code_dir, boot_file, hyperparameters,
                                        framework_type, framework_version, log_url, user_image_url,
                                        user_command, job_description, job_id, job_type, environment)
        self.volumes = volumes
        self.policy = policy
        self.trainingJob = TrainingJob(self.modelarts_session)

    def fit(self, inputs=None, dataset_id=None, dataset_version_id=None,
            data_source=None, wait=False, job_name=None,
            priority=constant.ROMA_TRAIN_JOB_DEFAULT_PRIORITY):
        """
        Train a model using the input training dataset.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param wait: whether wait the job completed or not
        :param job_name: job name
        :param priority: train job priority for roma, 3 2 1 is high middle low
        :return: job object
        """
        self._prepare_for_training(job_name=job_name)

        job_train_resp = self.submit_task(inputs, dataset_id, dataset_version_id,
                                          data_source, priority)

        if self.train_instance_type in constant.LOCAL_TRAIN_TYPE:
            return
        self.save_training_output(inputs, dataset_id, dataset_version_id, data_source, wait, job_train_resp)
        self.trainingJob.job_id = job_train_resp["metadata"].get("id", "")
        return self.trainingJob

    def prepare_config(self, inputs, dataset_id, dataset_version_id,
                       data_source, priority=constant.ROMA_TRAIN_JOB_DEFAULT_PRIORITY):
        """
        Organize all needed parameters to a dict.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param priority: priority of train job
        :return: job config
        """
        _config = dict()

        # train job priority for roma, 3 2 1 is high middle low
        _config["priority"] = priority

        _config['engine'] = dict()
        if self.user_image_url:
            _config['engine'].update({'image_url': self.user_image_url})

        if self.framework_version or self.framework_type:
            _config = self._prepare_params_engine(_config)

        if self.code_dir:
            _config['code_dir'] = self.code_dir

        if self.boot_file:
            _config['boot_file'] = self.boot_file

        if self.user_command:
            _config['command'] = self.user_command

        if isinstance(self.hyperparameters, list):
            dict_list = list()
            for dict_item in self.hyperparameters:
                dict_item.update({"name": dict_item.pop("label")})
                dict_list.append(dict_item)
            self.hyperparameters = dict_list
            _config['parameters'] = self.hyperparameters

        if self.output_path:
            _outputs = [{
                "remote": dict()
            }]
            _outputs[0].update({"name": "train_url"})
            _outputs[0]["remote"].update(
                {"obs": {"obs_url": self.output_path}})
            _config.update({"outputs": _outputs})

        _config = self._prepare_params_input(inputs, dataset_id,
                                             dataset_version_id, data_source,
                                             _config)

        return _config

    def _prepare_params_engine(self, _config):
        """
        Set engine for job config.
        :param _config: check engine_id
        :return: _config['engine_id']
        """
        if self.framework_version is None or self.framework_type is None:
            raise ValueError(
                'both framework_version and framework_type are needed')
        else:
            if self.user_image_url:
                _config['engine'].update({'engine_name': self.framework_type,
                                          'engine_version': self.framework_version})
                return _config
            res = self.trainingJob.get_engine_list(self.modelarts_session)
            engines = res['items']
            for engine in engines:
                if engine['engine_name'] == self.framework_type and \
                        engine['engine_version'] == self.framework_version:
                    _config['engine'].update({'engine_id': engine['engine_id']})

        return _config

    def _prepare_params_input(self, inputs, dataset_id, dataset_version_id,
                              data_source, _config):
        """
        Set input path for job config.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param _config: _config
        :return: _config
        """
        if inputs and dataset_id and dataset_version_id and data_source:
            raise ValueError('Pass either inputs or dataset_name and '
                             'dataset_version_id or data_source.')

        if (dataset_id and not dataset_version_id) or (
                not dataset_id and dataset_version_id):
            raise ValueError(
                'dataset_name and dataset_version_id are all needed.')

        _inputs = [{
            "remote": dict()
        }]
        if inputs:
            _inputs[0].update({"name": "data_url"})
            _inputs[0]["remote"].update({"obs": {"obs_url": inputs}})
            _config.update({"inputs": _inputs})
        elif dataset_id and dataset_version_id:
            _inputs[0].update({"name": "data_url"})
            _inputs[0]["remote"].update({"dataset": {
                "id": dataset_id,
                "version_id": dataset_version_id
            }})
            _config.update({"inputs": _inputs})
        else:
            logging.info('Set config by using other inputs or dataset.')

        return _config

    def _set_body(self, job_config):
        body = {
            "kind": "job",
            "metadata": {
                "name": self._current_job_name,
                "description": self.job_description
            },
            "algorithm": job_config,
            "spec": {
                "resource": {
                    "policy": self.policy,
                    "flavor_id": self.train_instance_type,
                    "node_count": self.train_instance_count
                }
            }
        }
        return body

    def start_new(self, inputs, dataset_id, dataset_version_id, data_source,
                  priority=constant.ROMA_TRAIN_JOB_DEFAULT_PRIORITY):
        """
        Create a new training job from the estimator.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param priority: priority of train job
        :return: training job object
        """
        super(Estimator, self).start_new(
            inputs, dataset_id, dataset_version_id, data_source)
        _config = self.prepare_config(
            inputs, dataset_id, dataset_version_id, data_source, priority)
        body = self._set_body(_config)

        if self.volumes:
            body["spec"].update({"volumes": self.volumes})

        if self.log_url:
            body["spec"].update(
                {"log_export_path":
                     {"obs_url": self.log_url,
                      "host_path": ""
                      }})

        return self.trainingJob.create_training_job(body)

    def print_job_middle_state(self, job_train_resp):
        """
        Print Training Job Middle State.
        :param job_train_resp: contains job_name job_id
        :return: None
        """
        job_name = job_train_resp["metadata"].get("name", "")
        job_id = job_train_resp["metadata"].get("id", "")

        count_init = 0
        count_running = 0
        count_waiting = 0
        while True:
            response, duration = self.get_job_state(job_id=job_id)
            if response == 'Completed':
                self.process_job_completed(response, duration, job_name)
                break
            elif response == 'Creating':
                count_init = self.process_job_init(response, count_init)
            elif response == 'Queuing':
                count_waiting = self.process_job_waiting(response, count_waiting)
            elif response == 'Running':
                count_running = self.process_job_running(response, count_running)
            else:
                logging.info("Job [ %s ] status is %s, please check log" % (
                    job_name, response))
                break

            count_total = count_init + count_running + count_waiting
            if count_total > int(
                    Config.getenv("COMMON_MAXIMUM_RETRY_TIMES")):
                logging.info("Reach the maximum start times, "
                             "the current status is %s" % response)
                break

    @classmethod
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        return cls(modelarts_session=modelarts_session).\
            trainingJob.get_job_list(modelarts_session, **kwargs)

    def get_job_info(self):
        return self.trainingJob.get_job_info(self.job_id)

    def update_job_configs(self, description):
        return self.trainingJob.update_job_configs(
            job_id=self.job_id, description=description)

    def get_job_log(self, task_id, **kwargs):
        return self.trainingJob.get_job_log(self.job_id, task_id,
                                            **kwargs)

    def get_job_metrics(self, task_id):
        return self.trainingJob.get_job_metrics(self.job_id, task_id)

    def get_job_state(self, job_id):
        """
        Get Specified Training Job State of job_id.
        :param job_id: job id
        :return:
        """
        res = self.trainingJob.get_job_info(job_id)
        secondary_phase = res['status']['secondary_phase']
        duration = res['status']['duration']
        return secondary_phase, duration

    @classmethod
    def get_engine_list(cls, modelarts_session):
        """
        Get Supported Engine List.
        """
        return cls(
            modelarts_session=modelarts_session).trainingJob.get_engine_list(
            modelarts_session)

    @classmethod
    def get_framework_list(cls, modelarts_session):
        """
        Get Supported Framework List.
        """
        return cls(modelarts_session=modelarts_session).trainingJob.get_framework_list(
            modelarts_session)

    @classmethod
    def control_job_by_id(cls, modelarts_session, job_id, **kwargs):
        return cls(
            modelarts_session=modelarts_session).trainingJob.control_job(
            job_id, **kwargs)


class TrainingJob(TrainingJobBase):

    def __init__(self, modelarts_session, job_id=None,
                 train_url=None, inputs=None, dataset_id=None,
                 dataset_version_id=None, data_source=None):
        """
        Initialize a ModelArts Training Job instance.
        """
        super(TrainingJob, self).__init__(modelarts_session, job_id, train_url, inputs, dataset_id,
                                          dataset_version_id, data_source)
        if modelarts_session.auth == constant.AKSK_AUTH:
            self._training_job = _TrainingJobApiAKSKImpl(modelarts_session)
        elif modelarts_session.auth == constant.ROMA_AUTH:
            self._training_job = _TrainingJobApiRomaImpl(modelarts_session)
        else:
            raise ValueError('Only support aksk authorization and roma authorization.')

    @classmethod
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        return cls(
            modelarts_session=modelarts_session)._training_job.get_job_list(
            modelarts_session, **kwargs)

    def get_job_info(self, job_id=None):
        """
        Get Training Job Info of Specified job_id.
        :param job_id: job id
        :return:
        """
        job_id = self._check_job_id(job_id)
        response = self._training_job.get_job_info(job_id)
        return response

    def get_job_log(self, job_id=None, task_id=None, **kwargs):
        """
        Get Training Job Log of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :param kwargs: support 'base_line', 'lines', 'order'
        :return:
        """
        job_id = self._check_job_id(job_id)
        return self._training_job.get_job_log(job_id, task_id, **kwargs)

    def get_job_metrics(self, job_id=None, task_id=None):
        """
        Get job metrics for training job.
        """
        job_id = self._check_job_id(job_id)
        return self._training_job.get_job_metrics(job_id, task_id)

    @classmethod
    def get_engine_list(cls, modelarts_session):
        """
        Get Supported Engine List.
        """
        return cls(
            modelarts_session=modelarts_session)._training_job.get_engine_list(
            modelarts_session)

    @classmethod
    def get_framework_list(cls, modelarts_session):
        """
        Get Supported Framework List.
        """
        session = cls(modelarts_session=modelarts_session)
        engine_list = session._training_job.get_engine_list(modelarts_session)
        return session._training_job.get_framework_list(modelarts_session, engine_list)

    def update_job_configs(self, job_id=None, **kwargs):
        """
        Update training job configs by job id.
        :param kwargs: support 'description'
        :return: None
        """
        job_id = self._check_job_id(job_id)
        if not kwargs:
            kwargs = dict()
        if ('description' not in kwargs):
            kwargs.update({"description": ""})
        self._training_job.update_job_configs(job_id=job_id, body=kwargs)

    def delete_job(self, job_id=None):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return: None
        """
        job_id = self._check_job_id(job_id)
        self._training_job.delete_job(job_id)
        count = 0
        while True:
            job_list_resp = self._training_job.get_job_list(
                self.modelarts_session)
            job_list = [item["metadata"]["id"]
                        for item in job_list_resp['items']]
            if job_id in job_list:
                count = count + 1
                time.sleep(3)
            else:
                logging.info('Successfully delete the job %s' % job_id)
                break
            if count == int(Config.getenv("COMMON_JOB_DELETE_RETRY_TIMES")):
                logging.info('Job %s is not deleted after 15s, please check it '
                             'from UI' % job_id)
                break
        if job_id is None:
            self.job_id = None

    def control_job(self, job_id=None, **kwargs):
        """
        Control Specified Training Job.
        :param job_id: job id
        :return:
        """
        job_id = self._check_job_id(job_id)
        if not kwargs:
            kwargs = dict()
        if ('action_type' not in kwargs or
                kwargs['action_type'] not in ["terminate"]):
            kwargs.update({"action_type": "terminate"})
        self._training_job.control_job(job_id=job_id, body=kwargs)
        count = 0
        while True:
            res = self._training_job.get_job_info(job_id)
            phase = res['status']['phase']
            if phase == "Terminated":
                logging.info('Successfully stop the job {}'.format(job_id))
                break
            else:
                count = count + 1
                time.sleep(3)
            if count == int(Config.getenv("COMMON_JOB_STOP_RETRY_TIMES")):
                logging.info('Job {} is not stop after 15s, please check it '
                             'from UI'.format(job_id))
                break
        return self._training_job.get_job_info(job_id)


class _TrainingJobApiAKSKImpl(TrainingJob):

    def __init__(self, modelarts_session):
        """
        Initialize a ModelArts Training Job instance when using AKSK auth.
        """
        self.modelarts_session = modelarts_session

    @classmethod
    @auth_expired_handler
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        request_url = "/v2/{project_id}/training-job-searches".format(
            project_id=modelarts_session.project_id)
        variable_name = locals()['kwargs']
        body_encode = JSONEncoder().encode(variable_name)
        return auth_by_apig(
            modelarts_session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_job_info(self, job_id):
        """
        Get Training Job Info of Specified job_id.
        :param job_id: job id
        :return: For example: {"metadata": {...},
                               "kind": "job",
                               "spec": {"resource": {...}, "log_export_path": {...}},
                               "status": {...}
                               "algorithm": {"inputs": [...], "outputs": [...], "engine": {...}, "policies": {...}}
                              }
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id))
        return auth_by_apig(
            self.modelarts_session, HTTPS_GET, request_url)

    @classmethod
    @auth_expired_handler
    def get_spec_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        :param modelarts_session: session
        :return:
        """
        request_url = "/v2/{project_id}/training-job-flavors".format(
            project_id=modelarts_session.project_id)
        return auth_by_apig(
            modelarts_session, HTTPS_GET, request_url)

    @classmethod
    @auth_expired_handler
    def get_train_instance_types(cls, modelarts_session, spec_info):
        """
        Get Supported Train Instance Types.
        :param modelarts_session: session
        :param spec_info:
        :return: For example: ['modelarts.vm.cpu.2u', 'modelarts.vm.gpu.v100NV32']
        """
        spec_list = []
        specs = spec_info['flavors']
        for spec in specs:
            spec_list.append(spec['flavor_id'])
        return spec_list

    @classmethod
    @auth_expired_handler
    def get_engine_list(cls, modelarts_session):
        """
        Get Supported Engine List.
        :param modelarts_session: session
        :return: For example: {"total": 9,
                               "items": [{"engine_id": "tensorflow-cp36-1.13.1-v2",
                                          "engine_name": "TensorFlow",
                                          "engine_version": "TF-1.13.1-python3.6-v2",
                                          "v1_compatible": false},
                                         ...
                                         {"engine_id": "kungfu-0.2.2-tf-1.13.1-python3.6",
                                          "engine_name": "KungFu",
                                          "engine_version": "KF-0.2.2-TF-1.13.1-python3.6",
                                          "v1_compatible": false}
                                         ]
                               }
        """
        request_url = "/v2/{project_id}/training-job-engines".format(
            project_id=modelarts_session.project_id)
        return auth_by_apig(
            modelarts_session, HTTPS_GET, request_url)

    @classmethod
    @auth_expired_handler
    def get_framework_list(cls, modelarts_session, engine_list):
        """
        Get Supported Framework List.
        :param modelarts_session: session
        :param engine_list:
        :return:For example: [{'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python2.7'},
                              {'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python3.6'},
                              ...
                              {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.0.0-python3.6'}]
        """
        framework_list = []
        engines = engine_list['items']
        for engine in engines:
            framework = {'framework_type': engine['engine_name'],
                         'framework_version': engine['engine_version']}
            framework_list.append(framework)
        return framework_list

    @classmethod
    @DeprecationWarning
    @auth_expired_handler
    def get_datasets(cls, modelarts_session, **kwargs):
        """
        Get Supported datasets.
        """
        request_url = '/v1/' + modelarts_session.project_id + '/datasets'
        variable_name = locals()['kwargs']
        params = {'offset', 'limit', 'sortBy', 'order', 'search_content',
                  'data_url'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(
            modelarts_session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def create_training_job(self, body):
        """
        Create Training Job.
        :param body: request body
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs".format(
            project_id=self.modelarts_session.project_id)
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_job_log(self, job_id, task_id, **kwargs):
        """
        Get Training Job Log of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :param kwargs: support 'base_line', 'lines', 'order'
        :return: For example: {"start_line": "1618891350486840192",
                               "lines": 50,
                               "end_line": "1618891353078423056",
                               "content": "Step 300,Training Accuracy 0.9298\nFinished!"}
        """
        variable_name = locals()['kwargs']
        request_url = "/v2/{project_id}/training-jobs/{job_id}/logs/{task_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        query = {}
        params = {'base_line', 'lines', 'order'}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(
            self.modelarts_session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def update_job_configs(self, job_id, body):
        """
        Update training job configs by job id.
        :param body: body for update training job configs
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        auth_by_apig(
            self.modelarts_session, HTTPS_PUT, request_url, body=body_encode)

    @auth_expired_handler
    def delete_job(self, job_id):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id))
        auth_by_apig(
            self.modelarts_session, HTTPS_DELETE, request_url)

    @auth_expired_handler
    def control_job(self, job_id, body):
        """
        Control Specified Training Job.
        :param job_id: job id
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/actions".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_job_metrics(self, job_id, task_id):
        """
        Get Training Job metrics of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :return: For example: {"metrics": [{"metric": "cpuUsage", "value": [1, 4.121]},
                                           {"metric": "memUsage", "value": [0, 0.024]},
                                           {"metric": "gpuUtil", "value": [0, 1]},
                                           {"metric": "gpuMemUsage", "value": [0, 1]}]}
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/metrics/{task_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        return auth_by_apig(self.modelarts_session, HTTPS_GET, request_url)


class _TrainingJobApiRomaImpl(TrainingJob):

    def __init__(self, modelarts_session):
        """
        Initialize a ModelArts Training Job instance when using Roma auth.
        """
        self.modelarts_session = modelarts_session

    @classmethod
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        request_url = "/v2/{project_id}/training-job-searches".format(
            project_id=modelarts_session.project_id)
        variable_name = locals()['kwargs']
        body_encode = JSONEncoder().encode(variable_name)
        return auth_by_roma_estimatorv2_api(
            modelarts_session, HTTPS_POST, request_url, body=body_encode)

    def get_job_info(self, job_id):
        """
        Get Training Job Info of Specified job_id.
        :param job_id: job id
        :return: For example: {"metadata": {...},
                               "kind": "job",
                               "spec": {"resource": {...}, "log_export_path": {...}},
                               "status": {...}
                               "algorithm": {"inputs": [...], "outputs": [...], "engine": {...}, "policies": {...}}
                              }
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.modelarts_session.project_id, job_id=str(job_id))
        return auth_by_roma_estimatorv2_api(
            self.modelarts_session, HTTPS_GET, request_url)

    @classmethod
    def get_spec_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        :param modelarts_session: session
        :return:
        """
        request_url = "/v2/{project_id}/training-job-flavors".format(
            project_id=modelarts_session.project_id)
        return auth_by_roma_estimatorv2_api(
            modelarts_session, HTTPS_GET, request_url)

    @classmethod
    def get_train_instance_types(cls, modelarts_session, spec_info):
        """
        Get Supported Train Instance Types.
        :param modelarts_session: session
        :param spec_info:
        :return: For example: ['modelarts.vm.cpu.2u', 'modelarts.vm.gpu.v100NV32']
        """
        spec_list = []
        specs = spec_info['flavors']
        for spec in specs:
            spec_list.append(spec['flavor_id'])
        return spec_list

    @classmethod
    def get_engine_list(cls, modelarts_session):
        """
        Get Supported Engine List.
        :param modelarts_session: session
        :return: For example: {"total": 9,
                               "items": [{"engine_id": "tensorflow-cp36-1.13.1-v2",
                                          "engine_name": "TensorFlow",
                                          "engine_version": "TF-1.13.1-python3.6-v2",
                                          "v1_compatible": false},
                                         ...
                                         {"engine_id": "kungfu-0.2.2-tf-1.13.1-python3.6",
                                          "engine_name": "KungFu",
                                          "engine_version": "KF-0.2.2-TF-1.13.1-python3.6",
                                          "v1_compatible": false}
                                         ]
                               }
        """
        request_url = "/v2/{project_id}/training-job-engines".format(
            project_id=modelarts_session.project_id)
        return auth_by_roma_estimatorv2_api(
            modelarts_session, HTTPS_GET, request_url)

    @classmethod
    def get_framework_list(cls, modelarts_session, engine_list):
        """
        Get Supported Framework List.
        :param modelarts_session: session
        :param engine_list:
        :return: For example: [{'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python2.7'},
                               {'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python3.6'},
                               ...
                               {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.0.0-python3.6'}]
        """
        framework_list = []
        engines = engine_list['items']
        for engine in engines:
            framework = {'framework_type': engine['engine_name'],
                         'framework_version': engine['engine_version']}
            framework_list.append(framework)
        return framework_list

    @classmethod
    @DeprecationWarning
    def get_datasets(cls, modelarts_session, **kwargs):
        """
        Get Supported datasets.
        """
        request_url = '/v1/' + modelarts_session.project_id + '/datasets'
        variable_name = locals()['kwargs']
        params = {'offset', 'limit', 'sortBy', 'order', 'search_content',
                  'data_url'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_roma_estimatorv2_api(
            modelarts_session, HTTPS_GET, request_url, query=query)

    def create_training_job(self, body):
        """
        Create Training Job.
        :param body: request body
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs".format(
            project_id=self.modelarts_session.project_id)
        body_encode = JSONEncoder().encode(body)
        return auth_by_roma_estimatorv2_api(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    def get_job_log(self, job_id, task_id, **kwargs):
        """
        Get Training Job Log of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :param kwargs: support 'base_line', 'lines', 'order'
        :return: For example: {"start_line": "1618891350486840192",
                               "lines": 50,
                               "end_line": "1618891353078423056",
                               "content": "Step 300,Training Accuracy 0.9298\nFinished!"}
        """
        variable_name = locals()['kwargs']
        request_url = "/v2/{project_id}/training-jobs/{job_id}/logs/{task_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        query = {}
        params = {'base_line', 'lines', 'order'}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_roma_estimatorv2_api(
            self.modelarts_session, HTTPS_GET, request_url, query=query)

    def update_job_configs(self, job_id, body):
        """
        Update training job configs by job id.
        :param body: body for update training job configs
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        auth_by_roma_estimatorv2_api(
            self.modelarts_session, HTTPS_PUT, request_url, body=body_encode)

    def delete_job(self, job_id):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id))
        auth_by_roma_estimatorv2_api(
            self.modelarts_session, HTTPS_DELETE, request_url)

    def control_job(self, job_id, body):
        """
        Control Specified Training Job.
        :param job_id: job id
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/actions".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        return auth_by_roma_estimatorv2_api(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    def get_job_metrics(self, job_id, task_id):
        """
        Get Training Job metrics of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :return: For example: {"metrics": [{"metric": "cpuUsage", "value": [1, 4.121]},
                                           {"metric": "memUsage", "value": [0, 0.024]},
                                           {"metric": "gpuUtil", "value": [0, 1]},
                                           {"metric": "gpuMemUsage", "value": [0, 1]}]}
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/metrics/{task_id}".format(
            project_id=self.modelarts_session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        return auth_by_roma_estimatorv2_api(
            self.modelarts_session, HTTPS_GET, request_url)
