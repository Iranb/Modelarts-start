# -*- coding: utf-8 -*
"""
Description: Huawei Cloud SWR management operate namespace and auth
Author: ModelArts SDK Team
Date: 2020/10/01 - 2020/10/30
"""

import os
from .config.auth import auth_by_apig
from . import constant
from json import JSONEncoder


class SWRManagement(object):
    """
        SWR Management, operate SWR object, create、get and delete  namespace
    """
    def __init__(self, session):

        """
        OBS Management initial include hwc obs.

        """

        self.session = session
        self.base_request_url = '/v2/manage/namespaces'
        self.swr_url = os.environ.get('IMAGE_REPO_URL')
        self.swr_api = "swr-api" + self.swr_url.split("swr")[1]

    def create_namespace(self, namespace):

        """ Send a request to swr service to create namespace
            :return response:
        """

        body = JSONEncoder().encode({"namespace": namespace})
        return auth_by_apig(self.session, constant.HTTPS_POST, self.base_request_url, body=body)

    def get_namespace(self, namespace=None):

        """ Send a request to swr service to get namespace
            :return namespace:
        """

        query = None
        if namespace:
            query = {"filter": "namespace::" + namespace}
        request_url = '/v2/manage/namespaces'
        res = auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query)
        return res["namespaces"]

    def delete_namespace(self, namespace):

        """ Send a request to swr service to delete namespace
            :return response:
        """

        request_url = os.path.join(self.base_request_url, namespace)
        return auth_by_apig(self.session, constant.HTTPS_DELETE, request_url)
