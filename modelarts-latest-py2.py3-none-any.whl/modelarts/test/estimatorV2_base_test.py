# -*- coding: utf-8 -*-
import logging
import random
import string
import sys
import time
import unittest

import pytest

from modelarts.estimatorV2 import Estimator
from modelarts.session import Session

logging.getLogger().setLevel(logging.INFO)
JOB_NAME_PREFIX = 'auto_test_'
session = Session(
    access_key="",
    secret_key="",
    project_id="",
    region_name="")


class EstimatorBaseTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        Unittest inheritance setUp.
        """
        logging.info('Start testing!')

    @classmethod
    def tearDownClass(cls):
        """
        Unittest inheritance tearDown.
        """
        logging.info('Test finished!')

    @staticmethod
    def wait_time(sec=20):
        logging.info('Start waiting ...')
        time.sleep(sec)
        logging.info('Already waiting for {} s'.format(sec))

    @staticmethod
    def get_random_name(prefix='', len_random=6, len_total=None):
        """
        :param prefix: 前缀（补全下划线）
        :param len_random: 随机字符串的长度
        :param len_total: 总长度（优先）
        """
        if prefix and not prefix.endswith('_'):
            prefix += '_'
        else:
            prefix = JOB_NAME_PREFIX

        length = len_random
        if len_total:
            length = len_total - len(prefix)
            length = 0 if length < 0 else length
        name = prefix + ''.join((random.choice(
            string.ascii_letters + string.digits * 3) for i in range(length)))
        return name

    @staticmethod
    def print_res_log(res):
        logging.info('{} Response:{}'.format(sys._getframe().f_code.co_name, res))

    @pytest.mark.level1
    def test_01_get_train_instance_types(self):
        res = Estimator.get_train_instance_types(modelarts_session=session)
        self.print_res_log(res)

    @pytest.mark.level1
    def test_02_get_framework_list(self):
        res = Estimator.get_framework_list(modelarts_session=session)
        self.print_res_log(res)

    @pytest.mark.level1
    def test_03_get_job_list(self):
        res = Estimator.get_job_list(modelarts_session=session)
        self.print_res_log(res)

    @pytest.mark.level1
    def test_04_get_job_info_0(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        estimator = Estimator(modelarts_session=session, job_id=job_instance.job_id)
        res = estimator.get_job_info()
        self.print_res_log(res)

    @pytest.mark.level1
    def test_05_get_job_info_1(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        res = job_instance.get_job_info()
        self.print_res_log(res)

    @pytest.mark.level1
    def test_06_update_job_configs(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        res = job_instance.update_job_configs(description='update description')
        self.print_res_log(res)

    @pytest.mark.level1
    def test_07_get_job_log_0(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        estimator = Estimator(modelarts_session=session, job_id=job_instance.job_id)
        res = estimator.get_job_log(task_id='worker-0')
        self.print_res_log(res)

    @pytest.mark.level1
    def test_08_get_job_log_1(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        res = job_instance.get_job_log(task_id='worker-0')
        self.print_res_log(res)

    @pytest.mark.level1
    def test_09_get_job_metrics_0(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        estimator = Estimator(modelarts_session=session, job_id=job_instance.job_id)
        res = estimator.get_job_metrics(task_id='worker-0')
        self.print_res_log(res)

    @pytest.mark.level1
    def test_10_get_job_metrics_1(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        res = job_instance.get_job_metrics(task_id='worker-0')
        self.print_res_log(res)

    @pytest.mark.level1
    def test_11_control_job_0(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        res = Estimator.control_job_by_id(modelarts_session=session,
                                          job_id=job_instance.job_id,
                                          action_type="terminate")
        self.print_res_log(res)

    @pytest.mark.level1
    def test_12_control_job_1(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        res = job_instance.control_job(action_type="terminate")
        self.print_res_log(res)

    @pytest.mark.level1
    def test_13_delete_job_0(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        Estimator.delete_job_by_id(modelarts_session=session, job_id=job_instance.job_id)

    @pytest.mark.level1
    def test_14_delete_job_1(self):
        job_instance = self.test_00_create_job()
        self.wait_time(20)
        job_instance.delete_job()
