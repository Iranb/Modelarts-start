# -*- coding: utf-8 -*-
import logging
import random
import string
import sys
import time
import unittest

import pytest

from modelarts.estimatorV2 import Estimator
from modelarts.session import Session
from modelarts.test.estimatorV2_base_test import EstimatorBaseTest

logging.getLogger().setLevel(logging.INFO)
JOB_NAME_PREFIX = 'auto_test_'
session = Session(
    w3_account='',
    app_id='',
    app_token='',
    region_name='')


class EstimatorRomaTestCase(EstimatorBaseTest, unittest.TestCase):
    @pytest.mark.level1
    def test_00_create_job(self):
        job_name = self.get_random_name(prefix=JOB_NAME_PREFIX, len_total=24)
        framework_type = 'TensorFlow'
        framework_version = 'TF-1.13.1-python3.6-v2'
        base_bucket_path = '/bucket-ce/sdk-test/tensorflow_mnist_digit_recognition'
        code_dir = base_bucket_path + '/train/'
        train_file = 'train_mnist.py'
        boot_file = base_bucket_path + '/train/' + train_file
        output_path = base_bucket_path + '/train_output_' + job_name + '/'
        log_url = base_bucket_path + '/train_log_' + job_name + '/'
        train_instance_type = 'modelarts.p3.large'
        train_instance_count = 1
        data_inputs = base_bucket_path + '/dataset/'

        estimator = Estimator(
            modelarts_session=session,
            framework_type=framework_type,
            framework_version=framework_version,
            code_dir=code_dir,
            boot_file=log_url,
            output_path=output_path,
            log_url=log_url,
            train_instance_type=train_instance_type,
            train_instance_count=train_instance_count,
            job_description='This is a train job for auto test.')
        job_instance = estimator.fit(
            inputs=data_inputs,
            job_name=job_name)
        self.print_res_log(job_instance.job_id)
        return job_instance
