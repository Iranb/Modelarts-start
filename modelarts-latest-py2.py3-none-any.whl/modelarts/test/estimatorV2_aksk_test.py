# -*- coding: utf-8 -*-
import logging
import random
import string
import sys
import time
import unittest

import pytest

from modelarts.estimatorV2 import Estimator
from modelarts.session import Session
from modelarts.test.estimatorV2_base_test import EstimatorBaseTest

logging.getLogger().setLevel(logging.INFO)
JOB_NAME_PREFIX = 'auto_test_'
session = Session(
    access_key="",
    secret_key="",
    project_id="",
    region_name="")


class EstimatorAKSKTestCase(EstimatorBaseTest, unittest.TestCase):
    @pytest.mark.level1
    def test_00_create_job(self):
        framework_type = 'XGBoost-Sklearn'
        framework_version = 'XGBoost-0.80-Sklearn-0.18.1-python3.6'
        code_dir = '/test-crq/program/code/xgb/'
        boot_file = '/test-crq/program/code/xgb/trainmodel.py'
        hyperparameters = [
            {"label": "classes",
             "value": "10"},
            {"label": "lr",
             "value": "0.001"}
        ]
        train_instance_type = 'modelarts.vm.cpu.8u'
        output_path = '/test-crq/train_output/'
        train_instance_count = 1
        data_inputs = '/test-crq/data/xgb_ml_sample/'

        job_name = self.get_random_name(prefix='io_para_desc_', len_total=24)
        estimator = Estimator(
            modelarts_session=session,
            framework_type=framework_type,
            framework_version=framework_version,
            code_dir=code_dir,
            boot_file=boot_file,
            hyperparameters=hyperparameters,
            train_instance_type=train_instance_type,
            output_path=output_path,
            train_instance_count=train_instance_count,
            job_description='io_para_description')
        job_instance = estimator.fit(
            inputs=data_inputs,
            job_name=job_name)
        self.print_res_log(job_instance.job_id)
        return job_instance

    @pytest.mark.level1
    def test_01_create_job_nfs(self):
        framework_type = 'PyTorch'
        framework_version = 'PyTorch-1.4.0-python3.6-v2'
        code_dir = '/test-wrk/xym/code/'
        boot_file = '/test-wrk/xym/code/test.py'
        train_instance_type = 'modelarts.vm.p100.large'
        output_path = '/modelarts-cn-north-7-d244cfc3/dj/'
        train_instance_count = 1
        volumes = [
            {"nfs": {
                "nfs_server_path": "10.0.0.94:/",
                "local_path": "/home/nfs",
                "read_only": False}
            }
        ]
        data_inputs = '/test-crq/data/xgb_ml_sample/'

        job_name = self.get_random_name(prefix='nfs_io_', len_total=15)
        estimator = Estimator(
            modelarts_session=session,
            framework_type=framework_type,
            framework_version=framework_version,
            code_dir=code_dir,
            boot_file=boot_file,
            train_instance_type=train_instance_type,
            output_path=output_path,
            train_instance_count=train_instance_count,
            volumes=volumes,
            job_description='pytorch-sentiment with ModelArts SDK')
        job_instance = estimator.fit(
            inputs=data_inputs,
            job_name=job_name)
        self.print_res_log(job_instance.job_id)
        return job_instance

    @pytest.mark.level1
    def test_02_create_job_custom_mirror(self):
        framework_type = 'TensorFlow'
        framework_version = 'TF-2.1.0-python3.6-v2'
        user_image_url = 'ei_modelarts_q00357245_01/modelarts_outter_base_tensorflow_2_1:train_py37_gpu-2.0.10-wf'
        train_instance_type = 'modelarts.vm.p100.large'
        train_instance_count = 1

        job_name = self.get_random_name(prefix='custom_mirror', len_total=30)
        estimator = Estimator(
            modelarts_session=session,
            framework_type=framework_type,
            framework_version=framework_version,
            user_command='sleep 100',
            user_image_url=user_image_url,
            train_instance_type=train_instance_type,
            train_instance_count=train_instance_count)
        job_instance = estimator.fit(job_name=job_name)
        self.print_res_log(job_instance.job_id)
        return job_instance
