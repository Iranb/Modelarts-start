
class ConfigException(RuntimeError):
    pass
