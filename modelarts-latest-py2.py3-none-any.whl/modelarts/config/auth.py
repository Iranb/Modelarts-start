""""
Authorize AKSK API and ROMA API
"""
import hashlib
import hmac
import json
import logging
from datetime import datetime, timedelta
import sys

if sys.version_info.major < 3:
    from urllib import quote
else:
    from urllib.parse import quote

import requests

from modelarts import constant
from ..auth.api.auth_api import AuthApi
from ..exception.apig_exception import APIGException
from ..exception.iam_exception import IAMException
from ..exception.roma_exception import RomaException
from ..util import apig_signer
from ..util.config import Config

logging.basicConfig()
LOGGER = logging.getLogger('modelarts-sdk')
TIMEOUT = int(Config.getenv("COMMON_REQUEST_TIME_OUT"))


def authorize(username, password, domain, region, api_client=None):
    """
    Set auth information to client configure
    :param username:  User name
    :param password:  User password
    :param domain:  Account name
    :return:  Huawei region
    :param api_client:  api_client
    :return: X-Subject-Token and IAM Resp
    """
    if not check_auth_validity(username):
        raise Exception("please input valid username")
    if not check_auth_validity(password):
        raise Exception("please input valid password")

    auth = {
        "auth": {
            "identity": {
                "methods": [
                    "password"
                ],
                "password": {
                    "user": {
                        "name": username,
                        "password": password,
                        "domain": {
                            "name": domain
                        }
                    }
                }
            },
            "scope": {
                "project": {
                    "domain": {
                        "name": domain
                    },
                    "name": region
                }
            }
        }
    }
    authapi = AuthApi(api_client)
    return_data, response_status, response_headers = authapi.authorize_with_http_info(
        auth)
    return response_headers['X-Subject-Token'], return_data


def get_temporary_aksk_without_agency(token, iam_url):
    """get IAM's temporary AK/SK without agency which lasts for 24h
       :return: {
                "credential": {
                    "access": "0HCKAXX*********QUP9GE",
                    "expires_at": "2019-08-03T01:22:55.858000Z",
                    "securitytoken": "gQtjbi1nbG9******iYW"
                    "secret": "2Cr05fTRfmeG*****nXpa538s0ny6Laqv"
                    }
                }
    """
    body = {
        "auth": {
            "identity": {
                "methods": [
                    "token"
                ],
                "token": {
                    "duration-seconds": "86400"
                }
            }
        }
    }
    headers = {
        "X-Auth-Token": token,
        "Content-Type": "application/json"
    }
    url = "https://" + iam_url + "/v3.0/OS-CREDENTIAL/securitytokens"
    try:
        response = requests.post(url, headers=headers, data=json.dumps(body),
                                 verify=False)
        if response.status_code > 300:
            resp = response.json()['error']
            message = "[ {} ] {}".format(resp['code'], resp['message'])
            raise IAMException(code=response.status_code, message=message)
        else:
            return response
    except IAMException:
        raise IAMException(code=response.status_code, message=message)
    except Exception as e:
        raise Exception(e)


def sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def get_signature_key(key, date_stamp, region_name, service_name):
    kDate = sign(('HWS' + key).encode('utf-8'), date_stamp)
    kRegion = sign(kDate, region_name)
    kService = sign(kRegion, service_name)
    kSigning = sign(kService, 'hws_request')
    return kSigning


def authorize_by_token(username, password, account, region, endpoint):
    """
    Set auth information to client configure
    :param username:  User name
    :param password:  User password
    :param account:  Account name
    :return:
    """
    if not check_auth_validity(username):
        raise Exception("please input valid username")
    if not check_auth_validity(password):
        raise Exception("please input valid password")
    if account is None and username is not None:
        account = username

    body = {
        "auth": {
            "identity": {
                "methods": [
                    "password"
                ],
                "password": {
                    "user": {
                        "name": username,
                        "password": password,
                        "domain": {
                            "name": account
                        }
                    }
                }
            },
            "scope": {
                "project": {
                    "domain": {
                        "name": account
                    },
                    "name": region
                }
            }
        }
    }
    headers = {
        "Content-Type": "application/json"
    }
    url = "https://" + endpoint + "/v3/auth/tokens"
    try:
        response = requests.post(url, headers=headers, data=json.dumps(body),
                                 verify=False)
        if response.status_code > 300:
            resp = response.json()['error']
            message = "[ {} ] {}".format(resp['code'], resp['message'])
            raise IAMException(code=response.status_code, message=message)
        else:
            token = response.headers['X-Subject-Token']
            project_id = response.json()['token']['project']['id']
            return token, project_id
    except IAMException:
        raise IAMException(code=response.status_code, message=message)
    except Exception as e:
        raise Exception(e)


def auth_by_roma_api(session, request_url, request_type, intf_action,
                     data=None, params=None):
    """ Call roma modelarts interface, get response
    :param session: session
    :param request_url: request url
    :param request_type: POST/GET
    :param data: body parameter
    :param params: index parameter
    :param intf_action: interface action, such as get_service_info, get_service_list
    :return: roma response
    """
    try:
        if request_type == constant.HTTPS_POST:
            response = requests.post(request_url, headers=session.headers,
                                     data=data, verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_GET and params is None:
            response = requests.get(request_url, headers=session.headers,
                                    verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_GET and params is not None:
            response = requests.delete(request_url, headers=session.headers,
                                       params=params, verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_DELETE:
            response = requests.delete(request_url, headers=session.headers,
                                       verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_PUT:
            response = requests.put(request_url, headers=session.headers,
                                    data=data, verify=False, timeout=TIMEOUT)
        else:
            raise Exception("no such https request %s." % request_type)

        if response.status_code >= 400:
            raise RomaException(code=response.status_code,
                                message=response.content)
        return json.loads(response.content)

    except Exception as e:
        raise Exception(intf_action + " failed, %s." % e)


def parse_req_query(req_query):
    """
    Parses request query dict to the URL format.
    :param query: request index parameter
    :return: query string
    """
    req_query_sortd = sorted(req_query)
    query_string_arr = []
    for query_key in req_query_sortd:
        query_value = req_query[query_key]
        query_kv = quote(query_key) + '=' + quote(query_value)
        query_string_arr.append(query_kv)
    return '&'.join(query_string_arr)


def auth_by_roma_estimatorv2_api(session, req_method, request_url,
                                 query=None, body=None):
    """
    Call modelarts estimator v2 api with roma auth, get response content
    :param session: session
    :param req_method: POST/GET/PUT/DELETE
    :param request_url: request url
    :param query: index parameter
    :param body: body parameter
    :param headers: request headers
    :return: estimator v2 api response content dict
    """
    request_url = session.host + request_url
    if query:
        query_string = parse_req_query(query)
        if query_string:
            request_url = request_url + '?' + query_string

    headers = session.headers
    if "X-Project-Id" not in headers.keys() and session.project_id:
        headers["X-Project-Id"] = session.project_id

    if body:
        resp = requests.request(req_method, request_url, headers=headers,
                                data=body, timeout=TIMEOUT, verify=False)
    else:
        resp = requests.request(req_method, request_url,
                                headers=headers, timeout=TIMEOUT, verify=False)

    if resp.status_code > 300:
        raise RomaException(
            code=resp.status_code, message=resp.reason, content=resp.content)
    return json.loads(resp.content) if len(resp.content) > 0 else None


def auth_by_apig(session, method, request_url, query=None, body=None, headers=None):
    sig = apig_signer.Signer()
    sig.AppKey = session.access_key
    sig.AppSecret = session.secret_key
    sig.user_id = session.user_id
    r = check_request(session, query, method, request_url, headers, body)

    sig.Sign(r)
    if body:
        resp = requests.request(r.method, r.scheme + "://" + r.host + r.uri,
                                headers=r.headers, data=r.body, timeout=TIMEOUT,
                                verify=False)
    else:
        resp = requests.request(r.method, r.scheme + "://" + r.host + r.uri,
                                headers=r.headers, timeout=TIMEOUT, verify=False)
    if resp.status_code > 300:
        raise APIGException(code=resp.status_code, message=resp.reason, content=resp.content)
    return json.loads(resp.content) if len(resp.content) > 0 else None


def check_request(session, query, method, request_url, headers=None, body=None):
    request = apig_signer.HttpRequest()
    request.scheme = "https"
    request.host = session.host
    request.method = method
    request.uri = request_url

    request.query = {}
    if query:
        request.query = query

    request.headers = {"Content-Type": "application/json"}
    if headers:
        request.headers = headers

    if session.user_id and "x-modelarts-user-id" not in request.headers.keys():
        request.headers["x-modelarts-user-id"] = session.user_id
    if session.security_token and "x-security-token" not in request.headers.keys():
        request.headers["x-security-token"] = session.security_token
    if "X-Project-Id" not in request.headers.keys() and session.project_id is not None:
        request.headers["X-Project-Id"] = session.project_id

    if body:
        request.body = body
    return request


def check_auth_validity(authinfo):
    """ check auth information validity
    :param authinfo: check auth information validity
    :return: False or True
    """
    if authinfo is None or authinfo == "":
        return False
    return True


class Token(object):
    """
    a singleton class for get IAM token by ak sk
    """

    def __init__(self):
        """
        Initialize a Token instance
        """
        self._token_expire_date = None
        self._iam_token = None

    @classmethod
    def get_instance(cls):
        """
            return instance, not safe for thread
        """
        if not hasattr(Token, "_instance"):
            Token._instance = Token()
        return Token._instance
