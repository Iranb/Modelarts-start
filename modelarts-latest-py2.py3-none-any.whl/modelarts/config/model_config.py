"""
Define Modelarts model management parameter structure
"""


class Params(object):
    """"
    Model create "input_params" and "output_params" structure
    """

    def __init__(self, url, param_name, param_type, min=None, max=None,
                 param_desc=None):
        """
        :param url: api url path
        :param param_name: parameter name, can't exceed 64 characters
        :param param_type: parameter type, include {int/string/float/timestamp/date/file}
        :param min: default null, when param-type is "int" or "float", it can fill in
        :param max: default null, when param-type is "int" or "float", it can fill in
        :param param_desc: default null, parameter description, can't exceed 100 characters
        """
        self.url = url
        self.param_name = param_name
        self.param_type = param_type
        self.min = min
        self.max = max
        self.param_desc = param_desc

    def print_params(self):
        """ print parameters
        """
        print("url = ", self.url)
        print("param_name = ", self.param_type)
        print("min = ", self.min)
        print("max = ", self.max)
        print("param_desc = ", self.param_desc)


class Dependencies(object):
    """
    The packages that need to install in runtime
    """

    def __init__(self, installer, packages):
        """
        :param installer:  install way, can choose "conda","yum","pip", "apt-get"
        :param packages: dependency package set
        """
        self.installer = installer
        self.packages = packages

    def print_dependencies(self):
        """ print parameters
        """
        print("installer = ", self.installer)
        self.packages.print_packages()

    def convert_to_dict(self):
        """ convert object to dict for submit job
        :return: dependency dict
        """
        dependency_dict = {"installer" : self.installer,
                           "packages" : []
                           }
        for package in self.packages:
            dependency_dict["packages"].append(package.convert_to_dict())

        return dependency_dict


class Packages(object):
    """
    Dependencies packages set
    """

    def __init__(self, package_name, package_version=None, restraint=None):
        """
        :param package_name: dependency package name
        :param package_version: dependency package version
        :param restraint: version restraint conditions, can choose "EXACT","ATLEAST","ATMOST"
        """
        self.package_name = package_name
        self.package_version = package_version
        self.restraint = restraint

    def print_packages(self):
        """ print packages parameters
        """
        print("package_name = ", self.package_name)
        print("package_version = ", self.package_version)
        print("restraint = ", self.restraint)

    def convert_to_dict(self):
        """ convert object to dict for submit job
            :return: package dict
        """
        package_dict = {
            "package_name" : self.package_name,
            "package_version" : self.package_version,
            "restraint" : self.restraint
        }
        return package_dict


class ServiceConfig(object):
    """
    Deploy model service configuration
    """

    def __init__(self, model_id, weight, specification, instance_count,
                 envs=None):
        """
        :param model_id: model id
        :param weight: weight percentage
        :param specification: resource specification,such as "modelarts.vm.cpu.2u"
        :param instance_count:  model deploy count
        :param envs: default null, environment variable
        """
        self.model_id = model_id
        self.weight = weight
        self.specification = specification
        self.instance_count = instance_count
        self.envs = envs

    def print_service_config(self):
        """print service configuration
        """
        print("model_id = ", self.model_id)
        print("weight = ", self.weight)
        print("specification = ", self.specification)
        print("instance_count = ", self.instance_count)
        print("envs = ", self.envs)

    def set_model_id(self, model_id):
        """
        Set model id.
        :param model_id: model id.
        """
        self.model_id = model_id


class TransformerConfig(object):
    """
    Deploy model transformer configuration
    """

    def __init__(self, model_id, specification, instance_count, src_path,
                 dest_path,
                 req_uri, mapping_type, mapping_rule=None, envs=None):
        """
        :param model_id: model id
        :param specification: resource specification,such as "modelarts.vm.cpu.2u"
        :param instance_count: model deploy count
        :param src_path: the obs path of batch task input data
        :param dest_path: the obs path of batch task output data
        :param req_uri:  the infer path of batch task
        :param mapping_type: input data mapping type
        :param mapping_rule: the mapping relationship between input data and csv data.
        :param envs: default null, environment variable
        """
        self.model_id = model_id
        self.specification = specification
        self.instance_count = instance_count
        self.src_path = src_path
        self.dest_path = dest_path
        self.req_uri = req_uri
        self.mapping_type = mapping_type
        self.mapping_rule = mapping_rule
        self.envs = envs

    def print_transformer_config(self):
        """print transformer configuration
        """
        print("model_id = ", self.model_id)
        print("specification = ", self.specification)
        print("instance_count = ", self.instance_count)
        print("src_path = ", self.src_path)
        print("dest_path = ", self.dest_path)
        print("req_uri = ", self.req_uri)
        print("mapping_type = ", self.mapping_type)
        print("mapping_rule = ", self.mapping_rule)
        print("envs = ", self.envs)


class Schedule(object):
    """
    Deploy model service schedule configuration
    """

    def __init__(self, op_type, time_unit, duration):
        """
        :param op_type: schedule type
        :param time_unit: weight percentage, DAYS/HOURS/MINUTES
        :param duration: time value
        """
        self.op_type = op_type
        self.time_unit = time_unit
        self.duration = duration

    def print_service_config(self):
        """print service configuration
        """
        print("op_type = ", self.op_type)
        print("time_unit = ", self.time_unit)
        print("duration = ", self.duration)
