class APIGException(Exception):
    def __init__(self, code=500, message="", content="", *arg):
        self.code = code
        self.message = message
        self.content = content
        self.args = arg
        if arg:
            Exception.__init__(self, code, message, content, arg)
        else:
            Exception.__init__(self, code, message, content)
